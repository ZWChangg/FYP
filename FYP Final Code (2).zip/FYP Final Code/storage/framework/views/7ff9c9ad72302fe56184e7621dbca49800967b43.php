
<?php $__env->startSection('content'); ?>

<div class="container">
<br>
    <h1>Points Management</h1>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <h3>Select User to View Points</h3>
    <form action="<?php echo e(route('showPoint')); ?>" method="get">
        <div class="form-group">
            <label for="user_id">User</label>
            <select name="user_id" id="user_id" class="form-control" required>
                <option value="">Select a user</option>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">View Points</button>
    </form>
    <br>
</div>
<br><br>
<div class="container">
<br>
    <?php if($selectedUser): ?>
        <h3>Transactions for <?php echo e($selectedUser->name); ?></h3>
        <br>
        <table class="table">
            <thead>
                <tr>
                    <th>Description</th>
                    <th>Points Changed</th>
                    <th>Transaction Type</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($transaction->description); ?></td>
                        <td><?php echo e($transaction->points_changed); ?></td>
                        <td><?php echo e(ucfirst($transaction->transaction_type)); ?></td>
                        <td><?php echo e($transaction->created_at->format('Y-m-d H:i')); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fyp2\fyp2\resources\views/showPoint.blade.php ENDPATH**/ ?>