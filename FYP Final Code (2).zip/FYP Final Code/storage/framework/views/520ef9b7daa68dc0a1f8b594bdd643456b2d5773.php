

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-2"></div>
    <div class="col-sm-8" style="color:white;">
        <br><br>
        <div class="d-flex align-items-center mb-3">
            <h3 class="mr-3">Barber Information</h3>
            <a href="UbarberCalendar" class="btn btn-black btn-square">
                <img src="<?php echo e(asset('images/calendar.jpeg')); ?>" alt="Button Image" class="img-fluid">
            </a>
        </div>
        <?php $__currentLoopData = $barbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card mb-3">
            <div class="card-header">
                <?php echo e($barber->name); ?>

            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-sm-4">
                        <?php if($barber->image): ?>
                            <img src="<?php echo e(asset('images/' . $barber->image)); ?>" alt="<?php echo e($barber->name); ?>" class="img-fluid" style="width:260px;height:230px;">
                        <?php else: ?>
                            <img src="<?php echo e(asset('images/empty.jpg')); ?>" alt="No Image" class="img-fluid">
                        <?php endif; ?>
                    </div>
                    <div class="col-sm-8">
                        <p><strong>Phone Number:</strong> <?php echo e($barber->phoneNo); ?></p>
                        <p><strong>Email:</strong> <?php echo e($barber->email); ?></p>
                        <p><strong>Information:</strong> <?php echo e($barber->information); ?></p>
                        <p><strong>Cost:</strong> RM<?php echo e($barber->cost); ?></p>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="col-sm-2"></div>
</div>

<style>
    body {
        background-image: url('images/shop2.jpg');
        background-size: cover;
        background-position: center;
        background-color: rgba(0, 0, 0, 0.7);
        background-blend-mode: overlay;
        width: 100%;
    }
    .card {
        margin-bottom: 10px;
        height: 330px;
        background-color: rgba(255, 255, 255, 0.2);
    }
    .btn-square {
        height: 40px; 
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 0;
        border-radius: 8px; /* Make sure the button is square */
        overflow: hidden; /* Hide any overflow of the image */
        position: relative; /* Make sure the image can be absolutely positioned inside */
    }
    .btn-square img {
        width: 100%; /* Make the image cover the width of the button */
        height: 100%; /* Make the image cover the height of the button */
        object-fit: cover; /* Ensure the image covers the button while maintaining its aspect ratio */
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Ulayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fyp2\fyp2\resources\views/UbarberInfo.blade.php ENDPATH**/ ?>