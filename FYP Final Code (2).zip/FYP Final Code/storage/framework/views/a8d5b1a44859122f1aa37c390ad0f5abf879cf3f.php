
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-1"></div>
    <div class="col-sm-10">
        <br><br>
        <!-- User Filter Form -->
        <form action="<?php echo e(route('showAppointment')); ?>" method="GET" class="form-inline mb-3">
            <label for="userSelect" class="mr-2">Select User:</label>
            <select name="user_id" id="userSelect" class="form-control mr-2">
                <option value="">All Users</option>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($user->id); ?>" <?php echo e($user->id == $selectedUser ? 'selected' : ''); ?>>
                        <?php echo e($user->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <button type="submit" class="btn btn-primary">Filter</button>
        </form>
        <br><br>

        <!-- Display Appointments Grouped by Date -->
        <?php $__currentLoopData = $appointments->groupBy('date'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $dailyAppointments): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h3><?php echo e($date); ?></h3>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <td>ID</td>
                        <td>Time</td>
                        <td>Phone Number</td>
                        <td>Outlet</td>
                        <td>Service</td>
                        <td>Barber</td>
                        <td>Voucher</td>
                        <td>Total Price</td>
                        <td>Total Time</td>
                        <td>Action</td>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $dailyAppointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($appointment->id); ?></td>
                        <td><?php echo e($appointment->time); ?></td>
                        <td><?php echo e($appointment->phoneNumber); ?></td>
                        <td><?php echo e($appointment->outlet); ?></td>
                        <td>
                            <?php
                                $servicesWithDetails = json_decode($appointment->service, true);
                                $serviceNames = [];

                                if (json_last_error() === JSON_ERROR_NONE && is_array($servicesWithDetails)) {
                                    $serviceNames = array_map(function($service) {
                                        return isset($service['name']) ? $service['name'] : 'Unknown Service';
                                    }, $servicesWithDetails);
                                } else {
                                    $serviceNames[] = 'Invalid service data';
                                }
                            ?>
                            <?php echo implode('<br>', $serviceNames); ?>

                        </td>
                        <td>
                            <?php if($appointment->barber): ?>
                                <?php echo e($appointment->barber->name); ?>

                                <img src="<?php echo e(asset('images/' . $appointment->barber->image)); ?>" alt="<?php echo e($appointment->barber->name); ?>" width="50">
                            <?php else: ?>
                                Not Assigned
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($appointment->redeemedVouchers->isNotEmpty()): ?>
                                <?php $__currentLoopData = $appointment->redeemedVouchers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $redeemedVoucher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($redeemedVoucher->voucher): ?>
                                        <?php echo e($redeemedVoucher->voucher->name); ?>

                                    <?php else: ?>
                                        No Voucher
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                No Voucher
                            <?php endif; ?>
                        </td>
                        <td>RM<?php echo e($appointment->totalPrice); ?></td>
                        <td><?php echo e(intdiv($appointment->totalTime, 60)); ?> hrs <?php echo e($appointment->totalTime % 60); ?> mins</td>
                        <td>
                            <a href="<?php echo e(route('editAppointment', ['id' => $appointment->id])); ?>" class="btn btn-warning btn-xs">Edit</a>
                            <a href="<?php echo e(route('deleteAppointment', ['id' => $appointment->id])); ?>" class="btn btn-danger btn-xs" onClick="return confirm('Are you sure to delete this appointment?')">Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="col-sm-1"></div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fyp2\fyp2\resources\views/showAppointment.blade.php ENDPATH**/ ?>