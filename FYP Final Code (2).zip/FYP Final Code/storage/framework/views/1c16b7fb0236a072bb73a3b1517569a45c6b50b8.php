

<?php $__env->startSection('content'); ?>

<br>
<div class="container">
    <h1>Redeemed Voucher Records</h1>

    <table class="table">
        <thead>
            <tr>
                <th>User Name</th>
                <th>Voucher Name</th>
                <th>Redeemed At</th>
                <th>Is Used</th>
                <th>Appointment ID</th> <!-- New column -->
                <th>Actions</th> <!-- Add an actions column -->
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $redeemedVouchers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $redeemedVoucher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($redeemedVoucher->user->name); ?></td>
                    <td><?php echo e($redeemedVoucher->voucher->name); ?></td>
                    <td><?php echo e($redeemedVoucher->created_at->format('Y-m-d H:i')); ?></td>
                    <td><?php echo e($redeemedVoucher->is_used ? 'Yes' : 'No'); ?></td>
                    <td><?php echo e($redeemedVoucher->appointment ? $redeemedVoucher->appointment->id : 'N/A'); ?></td>
                    <td>
                        <a href="<?php echo e(route('editRedeemedRecord', $redeemedVoucher->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fyp2\fyp2\resources\views/redeemedRecord.blade.php ENDPATH**/ ?>