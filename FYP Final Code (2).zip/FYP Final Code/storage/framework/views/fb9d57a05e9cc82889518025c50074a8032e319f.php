

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-2"></div>
    <div class="col-sm-8">
        <br><br>
        <h3>Barber Information</h3>
        <?php $__currentLoopData = $barbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card mb-3"> <!-- 添加 mb-3 类以增加每个卡片之间的间隔 -->
            <div class="card-header">
                <?php echo e($barber->name); ?>

            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-sm-4">
                        <?php if($barber->image): ?>
                            <img src="<?php echo e(asset('images/' . $barber->image)); ?>" alt="<?php echo e($barber->name); ?>" class="img-fluid" style="height: 250px; width: 250px;">
                        <?php else: ?>
                            <img src="<?php echo e(asset('images/empty.jpg')); ?>" alt="No Image" class="img-fluid">
                        <?php endif; ?>
                    </div>
                    <div class="col-sm-8">
                        <p><strong>Phone Number:</strong> <?php echo e($barber->phoneNo); ?></p>
                        <p><strong>Email:</strong> <?php echo e($barber->email); ?></p>
                        <p><strong>Information:</strong> <?php echo e($barber->information); ?></p>
                        <p><strong>Cost:</strong> RM<?php echo e($barber->cost); ?></p>
                        <div class="mt-3"> <!-- 添加 margin-top 来增加按钮的间距 -->
                            <td><a href="<?php echo e(route('editbarber',['id'=>$barber->id])); ?>" class="btn btn-warning btn-xs">
                            Edit</a>&nbsp;
                            <a href="<?php echo e(route('deletebarber',['id'=>$barber->id])); ?>" class="btn btn-danger btn-xs" 
                            onClick="return confirm('Are you sure to delete this menu?')">Delete</a></td>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="col-sm-2"></div>
</div>

<div class="position-fixed" style="bottom: 30px; right: 30px;"> <!-- 设置按钮的固定位置 -->
    <a href="<?php echo e(route('addbarber')); ?>" class="btn btn-primary">
        Add New Barber <i class="fas fa-plus"></i>
    </a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fyp2\fyp2\resources\views/barberInfo.blade.php ENDPATH**/ ?>