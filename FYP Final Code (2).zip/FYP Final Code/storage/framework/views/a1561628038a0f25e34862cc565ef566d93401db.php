<?php $__env->startSection('content'); ?>

<style>
    .text {
        color: white;
        text-align: center;
        font-family: 'Times New Roman', Times, serif;
        padding: 100px;
        opacity: 0; /* 开始时透明 */
        transform: translateY(50px); /* 向下偏移 */
        animation: slideIn 1s forwards; /* 添加滑入动画 */
    }

    @keyframes slideIn {
        0% {
            transform: translateY(50px); /* 向下偏移 */
            opacity: 0; /* 完全透明 */
        }
        100% {
            transform: translateY(0); /* 恢复到原位 */
            opacity: 1; /* 变为不透明 */
        }
    }

    .image {
        background-image: url('images/barber4.jpeg');
        background-size: cover;
        background-position: center;
        background-color: rgba(0, 0, 0, 0.8);
        background-blend-mode: overlay;
        width: 100%;
    }
</style>

<div class="a" style="text-align: center;padding: 50px 80px;text-align: justify;">
    <h6 id="demo" style="text-align: left;"></h6><br><br><br><br>
    <hr class="white-line">
    <h6 style="text-align: left;">Your Ultimate Destination for Precision Cuts and Expert Coloring!!!</h6>
    <h1 style="text-align: left;font-weight: bolder;">Cut Away A Thousand Worries,</h1>
    <h1 style="text-align: left;font-weight: bolder;">Perm Ten Thousands Styles </h1>
    <h6 style="text-align: left;">Ready for a fresh cut or a bold new color? It's easy to get started!!!</h6>
    <hr class="white-line"><br><br><br>
    <a href="UaddAppointment" id="appointmentBtn" class="btn btn-outline-info mr-2" role="button">Make New Appointment</a>
    <br><br><br>
</div>

<div class="image">
    <div class="text">
    <br><br>
        <h1 style="text-align: center;font-weight: bolder;">BUSINESS HOUR</h1>
        <h4 style="text-align: center;">9.00 a.m. - 8.30 p.m.</h4>
        <h4 style="text-align: center;">Open Everyday</h4>
        <br>
    </div>
</div>

<script>
    $(document).ready(function() {
        $('.dropdown').hover(function() {
            $(this).find('.dropdown-menu').addClass('show');
        }, function() {
            $(this).find('.dropdown-menu').removeClass('show');
        });

        $('#appointmentBtn').on('click', function(event) {
            event.preventDefault(); // 防止默认链接行为
            window.location.href = 'UaddAppointment'; // 跳转到预约页面
        });
    });

    setInterval(myTimer);

    function myTimer() {
        const d = new Date();
        document.getElementById("demo").innerHTML = d.toLocaleTimeString();
    }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Ulayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fyp2\fyp2\resources\views/home.blade.php ENDPATH**/ ?>