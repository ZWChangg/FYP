
<?php $__env->startSection('content'); ?>

<div class="container">
    <h2>Barber's Calendar</h2>
    
    <div class="form-group">
        <label for="barberSelect">Select Barber:</label>
        <select class="form-control" id="barberSelect">
            <option value="">Select a barber</option>
            <?php $__currentLoopData = $barbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($barber->id); ?>"><?php echo e($barber->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    
    <div id="calendar"></div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const calendarEl = document.getElementById('calendar');
    const barberSelect = document.getElementById('barberSelect');

    const calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        events: [], // Initialize with empty events
        eventClick: function(info) {
            const details = info.event.extendedProps.details;
            const detailString = `Barber name: ${details.barber_name}\nTime: ${details.time}\nEnd time: ${details.end_time}`;
            document.getElementById('eventDetails').textContent = detailString;
            $('#eventDetailsModal').modal('show');
        }
    });

    calendar.render();

    barberSelect.addEventListener('change', function() {
        const barberId = barberSelect.value;
        if (barberId) {
            fetch(`/calendarData/${barberId}`)
                .then(response => response.json())
                .then(schedules => {
                    console.log(schedules);
                    calendar.removeAllEvents();
                    calendar.addEventSource(schedules);
                });
        }
    });
});
</script>

<div class="modal fade" id="eventDetailsModal" tabindex="-1" role="dialog" aria-labelledby="eventDetailsModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="eventDetailsModalLabel" style="color:black">Appointment Details</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <pre id="eventDetails"></pre>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<style>
    #barberSelect {
        font-size: 18px; 
        padding: 10px; 
        width: 50%; 
    }
    .fc-toolbar .fc-button {
        font-size: 18px;
        padding: 20px;
        display: flex;
        justify-content: center;
        align-items: center;
        line-height: 2;
    }

    body {
        background-image: url('images/shop2.jpg');
        background-size: cover;
        background-position: center;
        background-color: rgba(0, 0, 0, 0.7);
        background-blend-mode: overlay;
        width: 100%;
        color: white;
    }
    .container {
        background-color: rgba(0, 0, 0, 0.5); 
        padding: 20px;
        border-radius: 10px;
    }
</style>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Ulayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fyp2\fyp2\resources\views/UbarberCalendar.blade.php ENDPATH**/ ?>