
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-1"></div>
    <div class="col-sm-10">
        <br><br>
        <a href="UaddAppointment" class="btn btn-primary" style="margin-right:10px;">Make Appointment</a>
        <br><br>
        <div class="body" style="position: relative; min-height: 500px;">
            <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $dailyAppointments): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h3><?php echo e($date); ?></h3>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Time</th>
                            <th>Phone Number</th>
                            <th>Outlet</th>
                            <th>Service</th>
                            <th>Barber</th>
                            <th>Voucher</th>
                            <th>Total Price</th>
                            <th>Total Time</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $dailyAppointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($appointment->id); ?></td>
                        <td><?php echo e($appointment->time); ?></td>
                        <td><?php echo e($appointment->phoneNumber); ?></td>
                        <td><?php echo e($appointment->outlet); ?></td>
                        <td>
                            <?php
                                $servicesWithDetails = json_decode($appointment->service, true);
                                $serviceNames = [];

                                if (json_last_error() === JSON_ERROR_NONE && is_array($servicesWithDetails)) {
                                    $serviceNames = array_map(function($service) {
                                        return isset($service['name']) ? $service['name'] : 'Unknown Service';
                                    }, $servicesWithDetails);
                                } else {
                                    $serviceNames[] = 'Invalid service data';
                                }
                            ?>
                            <?php echo implode('<br>', $serviceNames); ?>

                        </td>
                        <td>
                            <?php if($appointment->barber): ?>
                                <?php echo e($appointment->barber->name); ?>

                                <?php if($appointment->barber->image): ?>
                                    <img src="<?php echo e(asset('images/' . $appointment->barber->image)); ?>" alt="<?php echo e($appointment->barber->name); ?>" width="50">
                                <?php else: ?>
                                    No Image Available
                                <?php endif; ?>
                            <?php else: ?>
                                Not Assigned
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($appointment->redeemedVouchers->isNotEmpty()): ?>
                                <?php $__currentLoopData = $appointment->redeemedVouchers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $redeemedVoucher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($redeemedVoucher->voucher): ?>
                                        <?php echo e($redeemedVoucher->voucher->name); ?>

                                    <?php else: ?>
                                        No Voucher
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                No Voucher
                            <?php endif; ?>
                        </td>
                        <td>RM<?php echo e($appointment->totalPrice); ?></td>
                        <td><?php echo e(intdiv($appointment->totalTime, 60)); ?> hrs <?php echo e($appointment->totalTime % 60); ?> mins</td>
                        <td>
                            <a href="<?php echo e(route('UdeleteAppointment', ['id' => $appointment->id])); ?>" class="btn btn-danger btn-xs" onClick="return confirm('Are you sure to cancel this appointment?')">Cancel</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div class="col-sm-1"></div>
</div>

<style>
    body {
        background-image: url('images/shop2.jpg');
        background-size: cover;
        background-position: center;
        background-color: rgba(0, 0, 0, 0.7);
        background-blend-mode: overlay;
        width: 100%;
        color: white;
    }
    .table thead th {
        color: white;
    }
    .table tbody td {
        color: white;
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Ulayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fyp2\fyp2\resources\views/UshowAppointment.blade.php ENDPATH**/ ?>