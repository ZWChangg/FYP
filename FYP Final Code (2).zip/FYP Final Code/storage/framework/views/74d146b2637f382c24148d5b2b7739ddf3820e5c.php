
<?php $__env->startSection('content'); ?>
<br>
<div class="container">
    <br>
    <h3>Add Points</h3>
    <form action="<?php echo e(route('addPointt', $user->id)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="user">Select User</label>
            <select name="user_id" class="form-control" required>
                <option value="">Select a user</option>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?> (<?php echo e($user->email); ?>)</option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <label for="points">Points</label>
            <input type="number" name="points" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="description">Description (optional)</label>
            <input type="text" name="description" class="form-control">
        </div>
        <button type="submit" class="btn btn-primary">Add Points</button>
    </form>

    <br><br><br>
    <h3>Subtract Points</h3>
    <form action="<?php echo e(route('subPoint', $user->id)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="user">Select User</label>
            <select name="user_id" class="form-control" required>
                <option value="">Select a user</option>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?> (<?php echo e($user->email); ?>)</option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <label for="points">Points</label>
            <input type="number" name="points" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="description">Description (optional)</label>
            <input type="text" name="description" class="form-control">
        </div>
        <button type="submit" class="btn btn-danger">Subtract Points</button>
        <br><br>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fyp2\fyp2\resources\views/addPoint.blade.php ENDPATH**/ ?>