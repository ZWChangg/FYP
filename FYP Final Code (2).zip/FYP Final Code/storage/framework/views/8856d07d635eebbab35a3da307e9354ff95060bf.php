
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-1"></div>
    <div class="col-sm-10">
        <br><br>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Discount</th>
                    <th>Points Required</th> 
                    <th>Is Active</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $vouchers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $voucher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($voucher->id); ?></td>
                    <td><?php echo e($voucher->name); ?></td>
                    <td><?php echo e($voucher->discount); ?></td>
                    <td><?php echo e($voucher->points_required); ?></td> 
                    <td><?php echo e($voucher->is_active ? 'Active' : 'Inactive'); ?></td>
                    <td>
                        <a href="<?php echo e(route('editVoucher', $voucher->id)); ?>" class="btn btn-warning">Edit</a>
                        <a href="<?php echo e(route('deleteVoucher', $voucher->id)); ?>" class="btn btn-danger" onClick="return confirm('Are you sure you want to delete this voucher?')">Delete</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div class="col-sm-1"></div>
</div>
<div class="position-fixed" style="bottom: 30px; right: 30px;"> <!-- 设置按钮的固定位置 -->
    <a href="<?php echo e(route('addVoucher')); ?>" class="btn btn-primary">
        Add New Voucher <i class="fas fa-plus"></i>
    </a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fyp2\fyp2\resources\views/showVoucher.blade.php ENDPATH**/ ?>