
<?php $__env->startSection('content'); ?>
<div class="col-12" style="padding:0;">
    <div class="about-text">
        <div style="padding:40px">
            <h1>ABOUT US</h1>
            <br>
            <div style="font-size: 20px;text-align: left;">
                <p>
                    Our barber shop has been in operation for over ten years, 
                    dedicated to providing high-quality hair cutting and grooming services to every customer. 
                    Our goal is to create a warm and comfortable environment where every visitor feels at home.
                </p>
                <p>
                    We have a team of experienced and professional barbers, 
                    all of whom have undergone rigorous training and are skilled in various haircut techniques and the latest fashion trends. 
                    Whether you are looking for a classic style or aiming for the newest trends, 
                    our barbers will customize the perfect look based on your personal style and needs.
                </p>
                <p>    
                    In addition to haircuts, we offer a variety of additional services, including shampooing, conditioning, 
                    and styling, ensuring that you receive comprehensive care during every visit. 
                    We believe that a good hairstyle can boost one's confidence and charm, 
                    which is why we listen attentively to each customer's feedback, striving to exceed your expectations.
                </p>
                <p>    
                    Over the years, we have upheld the principle of “customer first,” 
                    and we are grateful for the support and trust of each patron. 
                    We warmly welcome new customers and hope to provide you with a pleasant and memorable haircut experience. 
                    Whenever you visit, you can find your unique style here. 
                    We look forward to welcoming you and creating beautiful moments together!
                </p>
            </div>
        </div>
    </div>
</div>
    <div class="contact-text col-12" style="font-size: 20px;text-align: center;">
        <h2>Contact Us</h2>
        <br>
        <p>WhatsApp: 012-345 6789</p>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Ulayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fyp2\fyp2\resources\views/UaboutUs.blade.php ENDPATH**/ ?>