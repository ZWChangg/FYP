
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-3"></div>
    <div class="col-sm-7">
        <br><br>
        <h3>Edit Barber</h3>
        <form action="<?php echo e(route('updateBarber', ['id' => $barber->id])); ?>" method="post" enctype='multipart/form-data'>
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group">
                <label for="barberName">Barber Name</label>
                <input class="form-control" type="text" id="barberName" name="barberName" value="<?php echo e(old('barberName', $barber->name)); ?>" required>
            </div>
            <div class="form-group">
                <label for="barberPhoneNo">Phone Number</label>
                <input class="form-control" type="text" id="barberPhoneNo" name="barberPhoneNo" value="<?php echo e(old('barberPhoneNo', $barber->phoneNo)); ?>" required>
            </div>
            <div class="form-group">
                <label for="barberEmail">Barber Email</label>
                <input class="form-control" type="text" id="barberEmail" name="barberEmail" value="<?php echo e(old('barberEmail', $barber->email)); ?>" required>
            </div>
            <div class="form-group">
                <label for="barberInfo">Barber Information</label>
                <input class="form-control" type="text" id="barberInfo" name="barberInfo" value="<?php echo e(old('barberInfo', $barber->information)); ?>" required>
            </div>
            <div class="form-group">
                <label for="barberImage">Image</label>
                <input class="form-control" type="file" id="barberImage" name="barberImage">
                <?php if($barber->image): ?>
                    <img src="<?php echo e(asset('images/' . $barber->image)); ?>" alt="<?php echo e($barber->name); ?>" width="100">
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="barberCost">Barber Cost</label>
                <input class="form-control" type="number" id="barberCost" name="barberCost" step="0.01" value="<?php echo e(old('barberCost', $barber->cost)); ?>" required>
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
        </form>
        <br><br>
    </div>
    <div class="col-sm-3"></div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fyp2\fyp2\resources\views/editBarber.blade.php ENDPATH**/ ?>