

<?php $__env->startSection('content'); ?>

<style>
    body {
        position: relative;
        background-image: url('/images/shop2.jpg');
        background-size: cover;
        background-position: center;
        color: white;
        width: 100%;
        height: 100%;
    }
    
    body::before {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.78);
        z-index: -1;
    }
    
    .card {
        background-color: rgba(0, 0, 0, 0.7);
        color: white;
    }

    .table {
        color: white;
    }

    .alert-success {
        color: green;
        background: none;
        border: none;
    }

    .alert-danger {
        color: red;
        background: none;
        border: none;
    }

    .transaction-row.hidden {
        display: none;
    }

    .show-more-btn {
        cursor: pointer;
        color:orange ;
        text-decoration: underline;
        background: none;
        border: none;
        padding: 0;
    }
</style>
<script>
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.redeem-button').forEach(button => {
        button.addEventListener('click', function() {
            const card = this.closest('.redeem-card');
            const pointsElement = document.getElementById('points');
            const points = parseInt(pointsElement.textContent);
            const pointsRequired = parseInt(card.getAttribute('data-points'));
            const voucherId = card.getAttribute('data-voucher-id');

            // Check if user has enough points
            if (points >= pointsRequired) {
                // Update displayed points
                pointsElement.textContent = points - pointsRequired;

                // Set hidden input value and submit form
                const redeemForm = document.getElementById('redeemForm');
                document.getElementById('voucherIdInput').value = voucherId;
                redeemForm.submit();
            } else {
                alert('You do not have enough points to redeem this voucher.');
            }
        });
    });
});
</script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const showMoreBtn = document.getElementById('showMoreBtn');
    const hiddenRows = document.querySelectorAll('.transaction-row.hidden');

    showMoreBtn.addEventListener('click', function() {
        hiddenRows.forEach(row => row.classList.toggle('hidden'));
        showMoreBtn.textContent = hiddenRows[0].classList.contains('hidden') ? 'Show More' : 'Show Less';
    });
});
</script>

<div class="row" style="position: relative; min-height: 1000px;">
    <div class="col-sm-3"></div>
    <div class="col-sm-7">
        <br><br>
        <form id="redeemForm" action="<?php echo e(route('UredeemPoint')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="voucher_id" id="voucherIdInput" value="">
            <div class="form-group">
                <h3 for="points">Your Points:</h3>
                <h1 id="points"><?php echo e($userPoints); ?></h1>
            </div>

            <div class="row">
                <div class="col-sm-12">
                    <br><br>
                    <h3>Redemption</h3>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $vouchers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $voucher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-6">
                        <div class="card redeem-card" data-voucher-id="<?php echo e($voucher->id); ?>" data-points="<?php echo e($voucher->points_required); ?>">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo e($voucher->name); ?></h5>
                                <p class="card-text"><?php echo e($voucher->points_required); ?> Points - Discount: RM<?php echo e($voucher->discount); ?></p>
                                <button class="btn btn-primary redeem-button" type="button">Redeem</button>
                            </div>
                        </div>
                        <br>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </form>

        <?php if(session('success')): ?>
            <p class="alert alert-success"><?php echo e(session('success')); ?></p>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <p class="alert alert-danger"><?php echo e($errors->first()); ?></p>
        <?php endif; ?>

        <br><br><br><br>
        <h3>Point Transactions</h3>
        <table class="table">
    <thead>
        <tr>
            <th>Description</th>
            <th>Points Changed</th>
            <th>Discount (RM)</th>
            <th>Transaction Type</th>
            <th>Date</th>
        </tr>
    </thead>
    <tbody>
        <?php
            $transactionsToShow = $transactions->take(3);
            $hiddenTransactions = $transactions->skip(3);
        ?>

        <?php $__currentLoopData = $transactionsToShow; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($transaction->description); ?></td>
                <td><?php echo e($transaction->points_changed); ?></td>
                <td><?php echo e($transaction->discount); ?></td>
                <td><?php echo e(ucfirst($transaction->transaction_type)); ?></td>
                <td><?php echo e($transaction->created_at->format('Y-m-d H:i')); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php $__currentLoopData = $hiddenTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="transaction-row hidden">
                <td><?php echo e($transaction->description); ?></td>
                <td><?php echo e($transaction->points_changed); ?></td>
                <td><?php echo e($transaction->discount); ?></td>
                <td><?php echo e(ucfirst($transaction->transaction_type)); ?></td>
                <td><?php echo e($transaction->created_at->format('Y-m-d H:i')); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
        <button id="showMoreBtn" class="show-more-btn">Show More</button>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Ulayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fyp2\fyp2\resources\views/UredeemPoint.blade.php ENDPATH**/ ?>