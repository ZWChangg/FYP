<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.10.2/fullcalendar.min.css" />
    <link href='https://cdn.jsdelivr.net/npm/fullcalendar@5.11.0/main.min.css' rel='stylesheet' />

    <title>Home</title>
    <style>
        body {
            font-family: 'Times New Roman', Times, serif;
        }
        
        * {
            box-sizing: border-box;
        }

        .container {
            border-radius: 5px;
            background-color: #f2f2f2;
            padding: 10px;
        }
        
        .row:after {
            content: "";
            display: table;
            clear: both;
        }
        
        @media screen and (max-width: 600px) {
            .column, input[type=submit] {
                width: 100%;
                margin-top: 0;
            }
        }

        .button {
            height: 60px;
            width: 70%;
            background-color: grey;
            margin-bottom: 20px;
            font-size: large;
        }

        span:first-child {
            display: flex;
            font-size: 1.125rem;
            padding-top: 1rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid var(--c-gray-600);
            font-weight: 300;
        }

        span:last-child {
            transition: 0.25s ease;
            display: flex;
            justify-content: center;
            align-items: center;
            width: 42px;
            height: 42px;
            border-radius: 50%;
            overflow: hidden;
            margin-left: 1.5rem;
            flex-shrink: 0;
        }

        .a {
            color: white;
            background-image: url('/images/d.jpg'); /* 确保路径正确 */
            background-size: cover;
            background-position: center;
            height: 100%;
            width: 100%;
        }

        .white-line {
            width: 700px;
            height: 1px;
            background-color: white;
            margin: 20px 0;
        }

        .btn-fab {
            position: fixed;
            bottom: 100px;
            right: 100px;
            z-index: 999;
        }
        
        .nav-item.active .nav-link {
            color: #ffcc00;
            font-weight: bold;
        }

        .about-text {
            color: aliceblue;
            text-align: center;
            width: 100%;
            background-image: url('/images/shop.jpg');
            background-color: rgba(0, 0, 0, 0.7);
            background-blend-mode: overlay;
            font-family: 'Times New Roman', Times, serif;
        }

        .contact-text{
            color: aliceblue;
            text-align: left;
            width: 100%;
            padding: 40px;
            background-color:black;
        }

    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="#">
        <img src="<?php echo e(asset('images/llogo.jpg')); ?>" style="width:40px;height:40px" class="img-fluid rounded-circle"> KWD
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
      
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto" style="font-size:20px;">
            <li class="nav-item <?php echo e(request()->is('home') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(url('home')); ?>">Home</a>
            </li>
            <li class="nav-item <?php echo e(request()->is('UbarberInfo') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(url('UbarberInfo')); ?>">View Barber</a>
            </li>
            <li class="nav-item <?php echo e(request()->is('UshowService') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(url('UshowService')); ?>">Service List</a>
            </li>
            <li class="nav-item <?php echo e(request()->is('UshowAppointment') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(url('UshowAppointment')); ?>">MyAppointment</a>
            </li>
            <li class="nav-item <?php echo e(request()->is('UappointmentHistory') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(url('UappointmentHistory')); ?>">History</a>
            </li>
            <li class="nav-item <?php echo e(request()->is('UredeemPoint') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(url('UredeemPoint')); ?>">Redeem Point </a>
            </li>
            <li class="nav-item <?php echo e(request()->is('UaboutUs') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(url('UaboutUs')); ?>">About Us</a>
            </li>
        </ul>
        <ul class="navbar-nav ml-auto">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <?php echo e(Auth::user()->name); ?>

                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                    <a class="dropdown-item" href="#" id="logoutBtn">Log Out</a>
                </div>
            </li>
        </ul>
    </div>
</nav>
 

<div class="container-fluid p-0">  
    <?php echo $__env->yieldContent('content'); ?>
</div>

<div class="row">
    <div class="col-12 text-left bg-dark" style="color: white;">
        <div style="margin-left: 20px;margin-top: 30px;float: left;margin-bottom: 30px;">
            <h5>KWD</h5>
            PTD 64888, 15 KM,<br>
            Jalan Skudai, P.O.Box 76,<br>
            81300 Skudai,<br>
            Johor, Malaysia<br>
            Phone: 012-3456789
        </div>
        <div style="float: left;margin-top: 30px;margin-left: 60px;">
            <h5>Email:</h5>
            KWD@barber.com<br><br>
        </div>
        <div style="float: left;margin-top: 30px;margin-left: 60px;">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3988.389126124463!2d103.67928727496609!3d1.5336266984520137!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31da73c109632e0b%3A0x74cda51bf210c304!2z5Y2X5pa55aSn5a2m5a2m6Zmi!5e0!3m2!1szh-TW!2smy!4v1703222144164!5m2!1szh-TW!2smy" width="200" height="200" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
        <div style="float: right;">
            <img src="https://th.bing.com/th/id/R.47bb3a15469bb794fa71e675eabc6655?rik=K7Uv88hbdVsEPg&riu=http%3a%2f%2fwww.sagraphics.co.uk%2fwp-content%2fuploads%2f2016%2f10%2fsocial-media-icons.png&ehk=S23qQrFW2HgKzp%2bBP9t6mkTPRAhEcVU5EA%2fqnGCRMgA%3d&risl=&pid=ImgRaw&r=0" alt="" style="float: right;" height="100px">
        </div>
    </div>
</div>


    <!-- Optional JavaScript -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.10.2/fullcalendar.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/moment.min.js"></script>
    <script src='https://cdn.jsdelivr.net/npm/fullcalendar@5.11.0/main.min.js'></script>
    
    <script>
        // Log Out Button Click Event
        document.getElementById('logoutBtn').addEventListener('click', function(event) {
            event.preventDefault(); 
            if (confirm('Are you sure you want to log out?')) { 
                document.getElementById('logout-form').submit();
            }
        });

        setInterval(myTimer);

        function myTimer() {
            const d = new Date();
            document.getElementById("demo").innerHTML = d.toLocaleTimeString();
        }
    </script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\fyp2\fyp2\resources\views/Ulayout.blade.php ENDPATH**/ ?>