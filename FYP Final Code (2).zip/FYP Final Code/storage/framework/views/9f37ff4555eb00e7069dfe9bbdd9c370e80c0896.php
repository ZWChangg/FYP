

<?php $__env->startSection('content'); ?>

<div class="container">
    <h1>Edit Redeemed Voucher Record</h1>

    <form action="<?php echo e(route('updateRedeemedRecord', $redeemedVoucher->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="form-group">
            <label for="is_used">Is Used:</label>
            <select class="form-control" id="is_used" name="is_used">
                <option value="1" <?php echo e($redeemedVoucher->is_used ? 'selected' : ''); ?>>Yes</option>
                <option value="0" <?php echo e(!$redeemedVoucher->is_used ? 'selected' : ''); ?>>No</option>
            </select>
        </div>

        <div class="form-group">
            <label for="appointment_id">Appointment ID:</label>
            <input type="number" class="form-control" id="appointment_id" name="appointment_id" value="<?php echo e($redeemedVoucher->appointment_id); ?>">
        </div>

        <button type="submit" class="btn btn-primary">Update</button>
        <a href="<?php echo e(route('redeemedRecord')); ?>" class="btn btn-secondary">Cancel</a>
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fyp2\fyp2\resources\views/editRedeemedRecord.blade.php ENDPATH**/ ?>