
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-3"></div>
    <div class="col-sm-6">
        <br><br>
        <h3>Edit Service</h3>
        <form action="<?php echo e(route('updateService')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="form-group">
                <label for="name">Name</label>
                <input class="form-control" type="text" id="name" name="name" required value="<?php echo e($service->name); ?>">
            </div>
            <div class="form-group">
            <label for="duration">Duration (minutes):</label>
            <input class="form-control" type="number" id="duration" name="duration" value="<?php echo e($service->duration); ?>" required>
            </div>
            <div class="form-group">
                <label for="cost">Price (RM)</label>
                <input class="form-control" type="number" id="cost" name="cost" min="0" required value="<?php echo e($service->cost); ?>">
            </div>
            <div class="form-group">
                <label for="image">Image</label>
                <input class="form-control" type="file" id="image" name="image">
                <?php if($service->image): ?>
                    <img src="<?php echo e(asset('images/' . $service->image)); ?>" alt="<?php echo e($service->image); ?>" width="100">
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="services">Services:</label>
                    <ul id="services">
                        <li><?php echo e($service); ?></li>
                    </ul>
            </div>
            <input type="hidden" name="id" value="<?php echo e($service->id); ?>">
            <button type="submit" class="btn btn-outline-primary">Update</button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </form>
        <br><br>
    </div>
    <div class="col-sm-3"></div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fyp2\fyp2\resources\views/editService.blade.php ENDPATH**/ ?>