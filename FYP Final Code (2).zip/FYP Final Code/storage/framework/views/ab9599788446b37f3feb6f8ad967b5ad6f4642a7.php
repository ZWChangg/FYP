
<?php $__env->startSection('content'); ?>
<style>
    .barber-card {
        display: flex;
        align-items: center;
        justify-content: space-between;
        border: none;
        background: none;
        height: 100%;
        text-align: left;
        padding: 10px;
        position: relative; /* 确保内部元素的绝对定位基于此容器 */
    }
    .barber-card img {
        width: 100px; /* 固定图片宽度 */
        height: 100px; /* 固定图片高度 */
        object-fit: cover; /* 保持图片比例并裁剪 */
        margin-left: 10px; /* 为图片添加左边距 */
    }
    .barber-card .card-title,
    .barber-card .card-text,
    .barber-card a {
        margin: 5px 0;
    }
    .barber-card-container {
        display: flex;
        flex-direction: column;
        height: 100%;
    }
    .form-check-input-barber {
        margin-right: 10px; /* 为 radio button 添加右边距 */
    }
    .form-check-label-barber {
        flex-grow: 1; /* 让标签占据剩余空间 */
        display: flex;
        flex-direction: column;
        align-items: center;
    }
    .barber-status {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        text-align: center;
        background-color: rgba(255, 255, 255, 0.7); /* 半透明背景 */
        padding: 5px 0;
        color: red;
    }
    .disabled img {
        filter: grayscale(100%); /* 变为灰色 */
    }
</style>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const checkboxes = document.querySelectorAll('.form-check-input[type="checkbox"]');
    const totalPriceDisplay = document.getElementById('totalPriceDisplay');
    const totalPriceInput = document.getElementById('totalPrice');
    const totalTimeDisplay = document.getElementById('totalTimeDisplay');
    const totalTimeInput = document.getElementById('totalTime');
    const endTimeDisplay = document.getElementById('endTimeDisplay');
    const services = <?php echo json_encode($services, 15, 512) ?>;
    const barbers = <?php echo json_encode($barbers, 15, 512) ?>;
    const vouchers = <?php echo json_encode($redeemedVouchers, 15, 512) ?>;
    const barberRadioButtons = document.querySelectorAll('input[name="barberID"]');
    const dateInput = document.getElementById('date');
    const timeSelect = document.getElementById('time');
    const voucherSelect = document.getElementById('voucherSelect');

    function formatTime(hours, minutes) {
        return String(hours).padStart(2, '0') + ':' + String(minutes).padStart(2, '0');
    }

    function updateTotalPriceAndTime() {
        let total = 0;
        let totalTime = 0;

        // Add service costs and durations
        checkboxes.forEach((checkbox) => {
            if (checkbox.checked) {
                const service = services.find(service => service.id == checkbox.value);
                if (service) {
                    total += parseFloat(service.cost);
                    totalTime += parseInt(service.duration);
                }
            }
        });

        // Add barber cost (no duration for barber)
        barberRadioButtons.forEach((radio) => {
            if (radio.checked) {
                const barber = barbers.find(barber => barber.id == radio.value);
                if (barber) {
                    total += parseFloat(barber.cost);
                }
            }
        });

        // Apply voucher discount
        const selectedVoucherId = voucherSelect.value;
            if (selectedVoucherId) {
                const voucher = vouchers.find(v => v.id == selectedVoucherId);
                if (voucher && voucher.discount) {
                    total -= parseFloat(voucher.discount);
                }
            }

        const hours = Math.floor(totalTime / 60);
        const minutes = totalTime % 60;

        // Update total price display
        totalPriceDisplay.textContent = 'Total Price: RM' + total.toFixed(2) + ' ++';
        totalPriceInput.value = total.toFixed(2);

        // Update total time display
        totalTimeDisplay.textContent = 'Total Time Spent: ' + hours + ' hrs ' + minutes + ' mins';
        totalTimeInput.value = totalTime;

        // Calculate and update end time
        const startTime = timeSelect.value.split(':');
        let endHours = parseInt(startTime[0]) + hours;
        let endMinutes = parseInt(startTime[1]) + minutes;

        if (endMinutes >= 60) {
            endMinutes -= 60;
            endHours += 1;
        }

        endTimeDisplay.textContent = 'End Time: ' + formatTime(endHours, endMinutes);
    }

    function updateDateConstraints() {
        const today = new Date();
        const yyyy = today.getFullYear();
        const mm = String(today.getMonth() + 1).padStart(2, '0');
        const dd = String(today.getDate()).padStart(2, '0');
        const minDate = `${yyyy}-${mm}-${dd}`;
        dateInput.setAttribute('min', minDate);
    }

    function updateTimeOptions() {
        const selectedDate = new Date(dateInput.value);
        const now = new Date();
        let minTime = '09:00';
        let maxTime = '20:30';

        if (selectedDate.toDateString() === now.toDateString()) {
            const hours = now.getHours();
            const minutes = now.getMinutes();

            if (minutes < 30) {
                minTime = formatTime(hours, 30);
            } else {
                minTime = formatTime(hours + 1, 0);
            }
        }

        generateTimeOptions(minTime, maxTime);
    }

    function generateTimeOptions(minTime, maxTime) {
        timeSelect.innerHTML = '';
        const [minHours, minMinutes] = minTime.split(':').map(Number);
        const [maxHours, maxMinutes] = maxTime.split(':').map(Number);

        for (let hour = 9; hour <= 20; hour++) {
            ['00', '30'].forEach(min => {
                if (
                    (hour > minHours) ||
                    (hour === minHours && min >= minMinutes) ||
                    (hour === maxHours && min <= maxMinutes)
                ) {
                    const option = document.createElement('option');
                    option.value = formatTime(hour, min);
                    option.textContent = formatTime(hour, min);
                    timeSelect.appendChild(option);
                }
            });
        }
    }

    function checkBarberAvailability() {
        const date = dateInput.value;
        const time = timeSelect.value;
        const selectedServices = Array.from(checkboxes)
            .filter(checkbox => checkbox.checked)
            .map(checkbox => checkbox.value);

        if (date && time) {
            fetch('<?php echo e(route('checkBarberAvailability')); ?>', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                },
                body: JSON.stringify({ date, time, services: selectedServices })
            })
            .then(response => response.json())
            .then(data => {
                barberRadioButtons.forEach(radio => {
                    const card = radio.parentElement.querySelector('.image-container');
                    if (data.unavailableBarbers.includes(parseInt(radio.value))) {
                        radio.disabled = true;
                        radio.parentElement.classList.add('text-muted');
                        card.classList.add('disabled');
                        let warning = card.querySelector('.barber-status');
                        if (!warning) {
                            warning = document.createElement('span');
                            warning.classList.add('text-danger', 'barber-status');
                            warning.textContent = 'Busy';
                            card.appendChild(warning);
                        }
                    } else {
                        radio.disabled = false;
                        radio.parentElement.classList.remove('text-muted');
                        card.classList.remove('disabled');
                        const warning = card.querySelector('.barber-status');
                        if (warning) {
                            warning.remove();
                        }
                    }
                });
            });
        }
    }

    checkboxes.forEach(checkbox => {
        checkbox.addEventListener('change', () => {
            updateTotalPriceAndTime();
            checkBarberAvailability();
        });
    });

    barberRadioButtons.forEach(radio => {
        radio.addEventListener('change', () => {
            updateTotalPriceAndTime();
            checkBarberAvailability();
        });
    });

    voucherSelect.addEventListener('change', () => {
        updateTotalPriceAndTime();
    });

    dateInput.addEventListener('change', () => {
        updateTimeOptions();
        checkBarberAvailability();
    });

    timeSelect.addEventListener('change', () => {
        updateTotalPriceAndTime();
        checkBarberAvailability();
    });

    updateTotalPriceAndTime(); // Initialize total price and time
    updateDateConstraints(); // Initialize date constraints
    updateTimeOptions(); // Initialize time options
});
</script>

<div class="container">
    <h3 style="text-align: center;">Edit Appointment</h3><br>
    <form action="<?php echo e(route('updateAppointment')); ?>" method="post" enctype='multipart/form-data'>
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" value="<?php echo e($appointment->id); ?>">
        
        <div class="form-group">
            <label for="date">Date:</label>
            <input class="form-control" type="date" id="date" name="date" required value="<?php echo e($appointment->date); ?>">
        </div>

        <div class="form-group">
            <label for="time">Time:</label>
            <select class="form-control" id="time" name="time" required>
                <option value="<?php echo e($appointment->time); ?>" selected><?php echo e($appointment->time); ?></option>
            </select>
        </div>

        <div class="form-group">
            <label for="phoneNumber">Phone Number:</label>
            <input class="form-control" type="text" id="phoneNumber" name="phoneNumber" required value="<?php echo e($appointment->phoneNumber); ?>">
        </div>

        <div class="form-group">
            <label for="outlet">Outlet:</label>
            <input class="form-control" type="text" id="outlet" name="outlet" required value="<?php echo e($appointment->outlet); ?>">
        </div>

        <div class="form-group">
            <label for="service">Services:</label><br>
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="service<?php echo e($service->id); ?>" name="service[]" value="<?php echo e($service->id); ?>"
                        <?php echo e(in_array($service->id, array_column(json_decode($appointment->service, true), 'id')) ? 'checked' : ''); ?>>
                    <label class="form-check-label" for="service<?php echo e($service->id); ?>">
                        <?php echo e($service->name); ?> - RM<?php echo e($service->cost); ?> - <?php echo e($service->duration); ?> minutes
                    </label>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
        <div class="form-group">
            <label for="barber">Choose a Barber:</label>
            <div class="form-row">
            <?php $__currentLoopData = $barbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <div class="form-check">
                    <input class="form-check-input" type="radio" id="barber<?php echo e($barber->id); ?>" name="barberID" value="<?php echo e($barber->id); ?>" <?php echo e($appointment->barber_id == $barber->id ? 'checked' : ''); ?> required>
                    <label class="form-check-label" for="barber<?php echo e($barber->id); ?>">
                        <img src="<?php echo e(asset('images/' . $barber->image)); ?>" alt="<?php echo e($barber->name); ?>" width="100">
                        <br><?php echo e($barber->name); ?> - RM<?php echo e($barber->cost); ?>

                    </label>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <div class="form-group">
            <label for="voucherSelect">Redeemed Vouchers:</label>
            <select class="form-control" id="voucherSelect" name="voucher">
                <option value="">None</option>
                <?php $__currentLoopData = $redeemedVouchers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $voucher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($voucher->id); ?>" 
                        <?php echo e($voucher->id == $appointment->voucher_id ? 'selected' : ''); ?>>
                        <?php echo e($voucher->voucher->name); ?> - RM<?php echo e($voucher->voucher->discount); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="form-group">
            <p id="totalPriceDisplay">Total Price: RM<?php echo e($appointment->totalPrice); ?></p>
            <input type="hidden" id="totalPrice" name="totalPrice" value="<?php echo e($appointment->totalPrice); ?>">
        </div>

        <div class="form-group">
            <p id="totalTimeDisplay">Total Time Spent: <?php echo e(floor($appointment->totalTime / 60)); ?> hrs <?php echo e($appointment->totalTime % 60); ?> mins</p>
            <input type="hidden" id="totalTime" name="totalTime" value="<?php echo e($appointment->totalTime); ?>">
        </div>

        <button class="btn btn-outline-primary" type="submit">Update</button>
    </form>
    <br><br>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fyp2\fyp2\resources\views/editAppointment.blade.php ENDPATH**/ ?>