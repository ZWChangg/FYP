
<?php $__env->startSection('content'); ?>
<script>
    function redirectToAnotherPage(viewPath) {
        window.location.href = viewPath;
    }
</script>
<div class="row">
    <div class="col-sm-2"></div>
    <div class="col-sm-6">
        <br><br>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <td>Name</td>
                    <td>Duration (minutes)</td>
                    <td>Price (RM)</td>
                    <td>Image</td>
                    <td>Action</td>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($service->name); ?></td>
                    <td><?php echo e($service->duration); ?></td>
                    <td><?php echo e($service->cost); ?></td>
                    <td>
                        <?php if($service->image): ?>
                            <img src="<?php echo e(asset('images/' . $service->image)); ?>" alt="<?php echo e($service->name); ?>" width="100">
                        <?php else: ?>
                            <span>No image available</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="<?php echo e(route('editService', ['id' => $service->id])); ?>" class="btn btn-warning btn-xs">Edit</a>&nbsp;
                        <a href="<?php echo e(route('deleteService', ['id' => $service->id])); ?>" class="btn btn-danger btn-xs" onClick="return confirm('Are you sure to delete this Service?')">Delete</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div class="col-sm-4"></div>
    <div class="col-sm-2"></div>
</div>

<div class="position-fixed" style="bottom: 30px; right: 30px;">
    <a href="<?php echo e(route('addService')); ?>" class="btn btn-primary">
        Add New Service <i class="fas fa-plus"></i>
    </a>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fyp2\fyp2\resources\views/showService.blade.php ENDPATH**/ ?>