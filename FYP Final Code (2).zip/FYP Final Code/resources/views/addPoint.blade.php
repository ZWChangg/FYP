@extends('layout')
@section('content')
<br>
<div class="container">
    <br>
    <h3>Add Points</h3>
    <form action="{{ route('addPointt', $user->id) }}" method="post">
        @csrf
        <div class="form-group">
            <label for="user">Select User</label>
            <select name="user_id" class="form-control" required>
                <option value="">Select a user</option>
                @foreach($users as $user)
                    <option value="{{ $user->id }}">{{ $user->name }} ({{ $user->email }})</option>
                @endforeach
            </select>
        </div>
        <div class="form-group">
            <label for="points">Points</label>
            <input type="number" name="points" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="description">Description (optional)</label>
            <input type="text" name="description" class="form-control">
        </div>
        <button type="submit" class="btn btn-primary">Add Points</button>
    </form>

    <br><br><br>
    <h3>Subtract Points</h3>
    <form action="{{ route('subPoint', $user->id) }}" method="post">
        @csrf
        <div class="form-group">
            <label for="user">Select User</label>
            <select name="user_id" class="form-control" required>
                <option value="">Select a user</option>
                @foreach($users as $user)
                    <option value="{{ $user->id }}">{{ $user->name }} ({{ $user->email }})</option>
                @endforeach
            </select>
        </div>
        <div class="form-group">
            <label for="points">Points</label>
            <input type="number" name="points" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="description">Description (optional)</label>
            <input type="text" name="description" class="form-control">
        </div>
        <button type="submit" class="btn btn-danger">Subtract Points</button>
        <br><br>
    </form>
</div>
@endsection