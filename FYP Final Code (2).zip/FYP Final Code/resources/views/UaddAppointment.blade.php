@extends('Ulayout')
@section('content')

<style>
    body {
        background-image: url('images/shop2.jpg');
        background-size: cover;
        background-position: center;
        background-color: rgba(0, 0, 0, 0.7);
        background-blend-mode: overlay;
        width: 100%;
        color: white;
    }
    .container {
        background-color: rgba(0, 0, 0, 0.5); 
        padding: 20px;
        border-radius: 10px;
    }

    .barber-card {
        display: flex;
        align-items: center;
        justify-content: space-between;
        border: none;
        background: none;
        height: 100%;
        text-align: left;
        padding: 10px;
        position: relative;
    }
    .barber-card img {
        height: 100px;
        object-fit: cover;
        margin-left: 10px;
    }
    .barber-card .card-title,
    .barber-card .card-text,
    .barber-card a {
        margin: 5px 0;
    }
    .barber-card-container {
        display: flex;
        flex-direction: column;
        height: 100%;
    }
    .form-check-input-barber {
        margin-right: 10px;
    }
    .form-check-label-barber {
        flex-grow: 1;
        display: flex;
        flex-direction: column;
        align-items: center;
    }
    .barber-status {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        text-align: center;
        background-color: rgba(255, 255, 255, 0.7);/
        padding: 5px 0;
        color: red;
    }
    .disabled img {
        filter: grayscale(100%);
    }
</style>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const checkboxes = document.querySelectorAll('.form-check-input[type="checkbox"]');
        const totalPriceDisplay = document.getElementById('totalPriceDisplay');
        const totalPriceInput = document.getElementById('totalPrice');
        const totalTimeDisplay = document.getElementById('totalTimeDisplay');
        const totalTimeInput = document.getElementById('totalTime');
        const endTimeDisplay = document.getElementById('endTimeDisplay');
        const services = @json($services);
        const barbers = @json($barbers);
        const vouchers = @json($redeemedVouchers);
        const barberRadioButtons = document.querySelectorAll('input[name="barberID"]');
        const dateInput = document.getElementById('date');
        const timeSelect = document.getElementById('time');
        const barberWarning = document.getElementById('barberWarning');
        const voucherSelect = document.getElementById('voucherSelect');
        const savedTotalPrice = localStorage.getItem('totalPrice');
        const savedTotalTime = localStorage.getItem('totalTime');
        const savedEndTime = localStorage.getItem('endTime');

        function formatTime(hours, minutes) {
            return String(hours).padStart(2, '0') + ':' + String(minutes).padStart(2, '0');
        }

        if (savedTotalPrice !== null) {
        document.getElementById('totalPrice').value = savedTotalPrice;
        document.getElementById('totalPriceDisplay').textContent = 'Total Price: RM' + savedTotalPrice + '++';
        }

        if (savedTotalTime !== null) {
            document.getElementById('totalTime').value = savedTotalTime;
            const totalTime = parseInt(savedTotalTime, 10);
            const hours = Math.floor(totalTime / 60);
            const minutes = totalTime % 60;
            document.getElementById('totalTimeDisplay').textContent = 'Total Time Spent: ' + hours + ' hrs ' + minutes + ' mins';
        }

        if (savedEndTime !== null) {
            document.getElementById('endTimeDisplay').textContent = 'End Time: ' + savedEndTime;
        }

        function updateTotalPriceAndTime() {
            let total = 0;
            let totalTime = 0;

            // Add service costs and durations
            checkboxes.forEach((checkbox) => {
                if (checkbox.checked) {
                    const service = services.find(service => service.id == checkbox.value);
                    if (service) {
                        total += parseFloat(service.cost);
                        totalTime += parseInt(service.duration);
                    }
                }
            });

            // Add barber cost (no duration for barber)
            barberRadioButtons.forEach((radio) => {
                if (radio.checked) {
                    const barber = barbers.find(barber => barber.id == radio.value);
                    if (barber) {
                        total += parseFloat(barber.cost);
                    }
                }
            });

            const selectedVoucherId = voucherSelect.value;
            if (selectedVoucherId) {
                const voucher = vouchers.find(v => v.id == selectedVoucherId);
                if (voucher && voucher.discount) {
                    total -= parseFloat(voucher.discount);
                }
            }

            const hours = Math.floor(totalTime / 60);
            const minutes = totalTime % 60;

            totalPriceDisplay.textContent = 'Total Price: RM' + total.toFixed(2) + '++';
            totalPriceInput.value = total.toFixed(2);

            totalTimeDisplay.textContent = 'Total Time Spent: ' + hours + ' hrs ' + minutes + ' mins';
            totalTimeInput.value = totalTime;

            const startTime = timeSelect.value.split(':');
            
            if (timeSelect.value) {
                let endHours = parseInt(startTime[0]) + hours;
                let endMinutes = parseInt(startTime[1]) + minutes;

                if (endMinutes >= 60) {
                    endMinutes -= 60;
                    endHours += 1;
                }

                endTimeDisplay.textContent = 'End Time: ' + formatTime(endHours, endMinutes);
            } else {
                endTimeDisplay.textContent = 'End Time: --:--';
            }
        }

        function updateDateConstraints() {
            const today = new Date();
            const yyyy = today.getFullYear();
            const mm = String(today.getMonth() + 1).padStart(2, '0');
            const dd = String(today.getDate()).padStart(2, '0');
            const minDate = `${yyyy}-${mm}-${dd}`;
            dateInput.setAttribute('min', minDate);
        }


        function updateTimeOptions() {
            const selectedDate = new Date(dateInput.value);
            const now = new Date();
            let minTime = '09:00';
            let maxTime = '20:30';

            if (selectedDate.toDateString() === now.toDateString()) {
                const hours = now.getHours();
                const minutes = now.getMinutes();

                if (minutes < 30) {
                    minTime = formatTime(hours, 30);
                } else {
                    minTime = formatTime(hours + 1, 0);
                }
            }

            generateTimeOptions(minTime, maxTime);
        }

        function generateTimeOptions(minTime, maxTime) {
            timeSelect.innerHTML = '<option value="">Select Time</option>';
            const [minHours, minMinutes] = minTime.split(':').map(Number);
            const [maxHours, maxMinutes] = maxTime.split(':').map(Number);

            for (let hour = minHours; hour <= maxHours; hour++) {
                const isLastHour = hour === maxHours;

                ['00', '30'].forEach(min => {
                    const optionTime = formatTime(hour, min);
                    if ((hour > minHours || min >= minMinutes) && (!isLastHour || min <= maxMinutes)) {
                        const option = document.createElement('option');
                        option.value = optionTime;
                        option.textContent = optionTime;
                        timeSelect.appendChild(option);
                    }
                });
            }
        }

        function checkBarberAvailability() {
            const date = dateInput.value;
            const time = timeSelect.value;
            const selectedServices = Array.from(checkboxes)
                .filter(checkbox => checkbox.checked)
                .map(checkbox => checkbox.value);

            if (date && time) {
                fetch('{{ route('checkBarberAvailability') }}', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    },
                    body: JSON.stringify({ date, time, services: selectedServices })
                })
                .then(response => response.json())
                .then(data => {
                    barberRadioButtons.forEach(radio => {
                    const card = radio.parentElement.querySelector('.image-container');
                    if (data.unavailableBarbers.includes(parseInt(radio.value))) {
                        radio.disabled = true;
                        radio.parentElement.classList.add('text-muted');
                        card.classList.add('disabled');
                        let warning = card.querySelector('.barber-status');
                        if (!warning) {
                            warning = document.createElement('span');
                            warning.classList.add('text-danger', 'barber-status');
                            warning.textContent = 'Busy';
                            card.appendChild(warning);
                        }
                    } else {
                        radio.disabled = false;
                        radio.parentElement.classList.remove('text-muted');
                        card.classList.remove('disabled');
                        const warning = card.querySelector('.barber-status');
                        if (warning) {
                            warning.remove();
                        }
                    }
                });
                });
            }
        }

        checkboxes.forEach(checkbox => {
            checkbox.addEventListener('change', () => {
                updateTotalPriceAndTime();
                checkBarberAvailability();
            });
        });

        barberRadioButtons.forEach(radio => {
            radio.addEventListener('change', () => {
                updateTotalPriceAndTime();  // Update total price and time when a barber is selected
                checkBarberAvailability();
            });
        });

        voucherSelect.addEventListener('change', () => {
            updateTotalPriceAndTime();
        });

        dateInput.addEventListener('change', () => {
            updateTimeOptions();
            checkBarberAvailability();
        });

        timeSelect.addEventListener('change', () => {
            updateTotalPriceAndTime();
            checkBarberAvailability();
        });

        updateTotalPriceAndTime(); // Initialize total price and time
        updateDateConstraints(); // Initialize date constraints
        updateTimeOptions(); // Initialize time options
    });
</script>

<div class="container">
    <h3 style="text-align: center;">Appointment</h3><br>
    <form action="{{ route('UaddAppointment.store') }}" method="post" enctype='multipart/form-data'>
        @csrf
        <div class="form-group">
            <label for="date">Date:</label>
            <input class="form-control" type="date" id="date" name="date" required>
        </div>

        <div class="form-group">
            <label for="time">Time:</label>
            <select class="form-control" id="time" name="time" required>
                <option value="">Select Time</option>
            </select>
        </div>

        <div class="form-group">
            <label for="phoneNumber">Phone Number:</label>
            <input class="form-control" type="text" id="phoneNumber" name="phoneNumber" required>
        </div>

        <div class="form-group">
            <label for="outlet">Outlet:</label>
            <select class="form-control" id="outlet" name="outlet" required>
                <option value="">Select an outlet</option>
                <option value="outlet1">Outlet 1 -- Johor</option>
            </select>
        </div>

        <div class="form-group">
            <label for="service">Services:</label><br>
            @foreach($services as $service)
            <div class="form-check">
                <input class="form-check-input" type="checkbox" id="service{{ $service->id }}" name="service[]" value="{{ $service->id }}">
                <label class="form-check-label" for="service{{ $service->id }}">{{ $service->name }} - RM{{ $service->cost }} - {{$service->duration}} minutes</label>
            </div>
            @endforeach
        </div>

        <div class="form-group">
            <label for="barber">Choose a Barber:</label>
            <div class="row">
                @foreach($barbers as $barber)
                <div class="col-md-4 mb-3 d-flex align-items-stretch">
                    <div class="barber-card-container">
                        <div class="barber-card">
                            <input class="form-check-input-barber" type="radio" id="barber{{ $barber->id }}" name="barberID" value="{{ $barber->id }}" required>
                            <label class="form-check-label-barber" for="barber{{ $barber->id }}">
                                <div class="image-container">
                                    <img src="{{ asset('images/' . $barber->image) }}" alt="{{ $barber->name }}" class="img-fluid mb-2">
                                </div>
                                <h5 class="card-title">{{ $barber->name }}</h5>
                                <p class="card-text">RM{{ $barber->cost }}</p>                                
                            </label>
                        </div>
                        <div style="text-align: center; width: 100%;">
                            <a href="{{ route('UbarberDetail', ['id' => $barber->id]) }}" class="btn btn-outline-warning mt-2" style="width: 150px;white-space: nowrap;">View Barber Details</a>
                        </div>
                    </div>
                </div>
                @endforeach
            </div>
        </div>

        <div class="form-group">
            <label for="voucherSelect">Redeemed Vouchers:</label>
            <select class="form-control" id="voucherSelect" name="voucher">
                <option value="">None</option>
                @foreach ($redeemedVouchers as $voucher)
                    <option value="{{ $voucher->id }}">{{ $voucher->voucher->name }} - RM{{ $voucher->voucher->discount }}</option>
                @endforeach
            </select>
        </div>

        <div class="form-group">
            <p id="totalPriceDisplay">Total Price: RM0.00</p>
            <input type="hidden" id="totalPrice" name="totalPrice" value="0">
        </div>

        <div class="form-group">
            <p id="totalTimeDisplay">Total Time Spent: 0 hrs 0 mins</p>
            <input type="hidden" id="totalTime" name="totalTime" value="0">
        </div>

        <div class="form-group">
            <p id="endTimeDisplay">End Time: --:--</p>
        </div>

        <button class="btn btn-outline-warning" type="submit">Add New</button>
    </form>
    <br><br>
</div>

@endsection