@extends('layout')

@section('content')
<div class="row">
    <div class="col-sm-1"></div>
    <div class="col-sm-10">
        <br><br>
        <div style="position: relative; min-height: 500px;">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Phone Number</th>
                        <th>Outlet</th>
                        <th>Service</th>
                        <th>Barber</th>
                        <th>Total Price</th>
                        <th>Total Time</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($appointments as $appointment)
                    <tr>
                        <td>{{ $appointment->id }}</td>
                        <td>{{ $appointment->date }}</td>
                        <td>{{ $appointment->time }}</td>
                        <td>{{ $appointment->phoneNumber }}</td>
                        <td>{{ $appointment->outlet }}</td>
                        <td>
                            @php
                                $servicesWithDetails = json_decode($appointment->service, true);
                                $serviceNames = [];

                                if (json_last_error() === JSON_ERROR_NONE && is_array($servicesWithDetails)) {
                                    $serviceNames = array_map(function($service) {
                                        return isset($service['name']) ? $service['name'] : 'Unknown Service';
                                    }, $servicesWithDetails);
                                } else {
                                    $serviceNames[] = 'Invalid service data';
                                }
                            @endphp
                            {!! implode('<br>', $serviceNames) !!}
                        </td>
                        <td>
                            @if($appointment->barber)
                                {{ $appointment->barber->name }}
                                <img src="{{ asset('images/' . $appointment->barber->image) }}" alt="{{ $appointment->barber->name }}" width="50">
                            @else
                                Not Assigned
                            @endif
                        </td>
                        <td>RM{{ $appointment->totalPrice }}</td>
                        <td>{{ intdiv($appointment->totalTime, 60) }} hrs {{ $appointment->totalTime % 60 }} mins</td>
                    </tr>
                    @endforeach
                </tbody>
            </table> 
        </div>
    </div>
    <div class="col-sm-1"></div>
</div>
@endsection
