@extends('layout')
@section('content')

<div class="container">
<br>
    <h1>Points Management</h1>

    @if (session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    <h3>Select User to View Points</h3>
    <form action="{{ route('showPoint') }}" method="get">
        <div class="form-group">
            <label for="user_id">User</label>
            <select name="user_id" id="user_id" class="form-control" required>
                <option value="">Select a user</option>
                @foreach ($users as $user)
                    <option value="{{ $user->id }}">{{ $user->name }}</option>
                @endforeach
            </select>
        </div>
        <button type="submit" class="btn btn-primary">View Points</button>
    </form>
    <br>
</div>
<br><br>
<div class="container">
<br>
    @if ($selectedUser)
        <h3>Transactions for {{ $selectedUser->name }}</h3>
        <br>
        <table class="table">
            <thead>
                <tr>
                    <th>Description</th>
                    <th>Points Changed</th>
                    <th>Transaction Type</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($transactions as $transaction)
                    <tr>
                        <td>{{ $transaction->description }}</td>
                        <td>{{ $transaction->points_changed }}</td>
                        <td>{{ ucfirst($transaction->transaction_type) }}</td>
                        <td>{{ $transaction->created_at->format('Y-m-d H:i') }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    @endif
</div>

@endsection