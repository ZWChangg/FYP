@extends('Ulayout')
@section('content')

<h2>Your Redeemed Vouchers</h2>

<table>
    <tr>
        <th>Voucher Name</th>
        <th>Discount</th>
        <th>Is Used</th>
        <th>Redeemed At</th>
    </tr>
    @foreach($redeemedVouchers as $redeemedVoucher)
    <tr>
        <td>{{ $redeemedVoucher->voucher->name }}</td>
        <td>{{ $redeemedVoucher->voucher->discount }}</td>
        <td>{{ $redeemedVoucher->is_used ? 'Yes' : 'No' }}</td>
        <td>{{ $redeemedVoucher->created_at }}</td>
    </tr>
    @endforeach
</table>

@endsection