@extends('layouts.app')

@section('content')
<div class="container d-flex justify-content-center align-items-center" style="min-height: 100vh;">
    <div class="col-md-6 col-lg-4"> <!-- Adjusted width for better alignment -->
        <div class="card">
            <div class="card-header text-center">{{ __('Admin Login') }}</div>

            <div class="card-body">
                <form method="POST" action="{{ route('admin.login') }}">
                    @csrf
                    <div class="mb-3">
                        <label for="admin_id" class="form-label">{{ __('Admin ID') }}</label>
                        <input id="admin_id" type="text" class="form-control @error('admin_id') is-invalid @enderror" name="admin_id" required autofocus autocomplete="off">

                        @error('admin_id')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                        @enderror
                    </div>

                    <div class="d-flex justify-content-center">
                        <button type="submit" class="btn btn-primary">{{ __('Login') }}</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
