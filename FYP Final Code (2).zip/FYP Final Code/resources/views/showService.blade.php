@extends('layout')
@section('content')
<script>
    function redirectToAnotherPage(viewPath) {
        window.location.href = viewPath;
    }
</script>
<div class="row">
    <div class="col-sm-2"></div>
    <div class="col-sm-6">
        <br><br>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <td>Name</td>
                    <td>Duration (minutes)</td>
                    <td>Price (RM)</td>
                    <td>Image</td>
                    <td>Action</td>
                </tr>
            </thead>
            <tbody>
                @foreach($services as $service)
                <tr>
                    <td>{{ $service->name }}</td>
                    <td>{{ $service->duration }}</td>
                    <td>{{ $service->cost }}</td>
                    <td>
                        @if($service->image)
                            <img src="{{ asset('images/' . $service->image) }}" alt="{{ $service->name }}" width="100">
                        @else
                            <span>No image available</span>
                        @endif
                    </td>
                    <td>
                        <a href="{{ route('editService', ['id' => $service->id]) }}" class="btn btn-warning btn-xs">Edit</a>&nbsp;
                        <a href="{{ route('deleteService', ['id' => $service->id]) }}" class="btn btn-danger btn-xs" onClick="return confirm('Are you sure to delete this Service?')">Delete</a>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
    <div class="col-sm-4"></div>
    <div class="col-sm-2"></div>
</div>

<div class="position-fixed" style="bottom: 30px; right: 30px;">
    <a href="{{ route('addService') }}" class="btn btn-primary">
        Add New Service <i class="fas fa-plus"></i>
    </a>
</div>

@endsection
