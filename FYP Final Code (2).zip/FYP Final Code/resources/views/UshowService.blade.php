@extends('Ulayout')
@section('content')

<style>
    body, html {
        height: 100%;
        margin: 0;
        font-family: 'Times New Roman', Times, serif;
        background-color: black;
    }

    .header-text {
        text-align: center;
        color: #ffcc00;
        font-family: 'MV Boli', Times, serif;
        font-size: 50px;
        margin-top: 30px;
    }

    .container-fluid {
        padding: 50px;
    }

    .image-container {
        position: relative;
        width: 100%;
        height: 300px;
        float: left;
        margin-right: 20px;
        overflow: hidden;
    }

    .image {
        width: 100%;
        height: 100%;
        object-fit: cover;
        display: block;
    }

    .overlay {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
        color: white;
        font-size: 35px;
        display: flex;
        align-items: center;
        justify-content: center;
        text-align: center;
        transform: translateY(100%);
        transition: transform 0.3s ease;
    }

    .image-container:hover .overlay {
        transform: translateY(0);
    }

    .white-line {
        width: 700px; 
        height: 1px; 
        background-color: white; 
        margin: 20px 0;
    }
</style>

<div class="header-text">
    <div style="margin-right: 140px;">The Best Service!</div>
    <div style="margin-left: 140px;">The Best Results!</div>
</div>

<div class="container-fluid">
    <div class="row">
        @foreach($services as $service)
        <div class="col-md-4 mb-4">
            <div class="image-container">
                @if($service->image)
                    <img src="{{ asset('images/' . $service->image) }}" alt="{{ $service->name }}" class="image">
                @else
                    <img src="{{ asset('images/default.jpg') }}" alt="Default Image" class="image">>
                @endif
                <div class="overlay">{{ $service->name }}<br>RM{{ number_format($service->cost, 2) }}</div>
            </div>
        </div>
        @endforeach
    </div>
</div>

<div class="row col-12">
    <div class="col-md-4">
        <img src="{{asset('images/barber.jpeg')}}" alt="" style="width: 100%;margin: 80px;">
    </div>
    <div class="col-md-6" style="color: rgb(186, 128, 28);margin-top: 100px;margin-left: 140px;font-family: 'MV Boli', Times, serif;">
        <h1 style="text-align: center;">Best For You</h1>
        <br>
        <p style="font-size:20px;">To provide the best service, we use only the finest tools. 
            Our barbers have many years of experience and are skilled in a variety of haircut techniques, 
            ensuring personalized service for each customer. Whether you prefer classic styles or trendy looks, 
            we are dedicated to delivering the best results. 
            We value the needs of every customer and strive to make your haircut experience enjoyable in a relaxed atmosphere. 
            Choose us, and you will experience professional, 
            high-quality barber services that boost your confidence and charm!
        </p>
    </div>
</div>

@endsection
