@extends('Ulayout')

@section('content')

<style>
    body {
        position: relative;
        background-image: url('/images/shop2.jpg');
        background-size: cover;
        background-position: center;
        color: white;
        width: 100%;
        height: 100%;
    }
    
    body::before {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.78);
        z-index: -1;
    }
    
    .card {
        background-color: rgba(0, 0, 0, 0.7);
        color: white;
    }

    .table {
        color: white;
    }

    .alert-success {
        color: green;
        background: none;
        border: none;
    }

    .alert-danger {
        color: red;
        background: none;
        border: none;
    }

    .transaction-row.hidden {
        display: none;
    }

    .show-more-btn {
        cursor: pointer;
        color:orange ;
        text-decoration: underline;
        background: none;
        border: none;
        padding: 0;
    }
</style>
<script>
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.redeem-button').forEach(button => {
        button.addEventListener('click', function() {
            const card = this.closest('.redeem-card');
            const pointsElement = document.getElementById('points');
            const points = parseInt(pointsElement.textContent);
            const pointsRequired = parseInt(card.getAttribute('data-points'));
            const voucherId = card.getAttribute('data-voucher-id');

            // Check if user has enough points
            if (points >= pointsRequired) {
                // Update displayed points
                pointsElement.textContent = points - pointsRequired;

                // Set hidden input value and submit form
                const redeemForm = document.getElementById('redeemForm');
                document.getElementById('voucherIdInput').value = voucherId;
                redeemForm.submit();
            } else {
                alert('You do not have enough points to redeem this voucher.');
            }
        });
    });
});
</script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const showMoreBtn = document.getElementById('showMoreBtn');
    const hiddenRows = document.querySelectorAll('.transaction-row.hidden');

    showMoreBtn.addEventListener('click', function() {
        hiddenRows.forEach(row => row.classList.toggle('hidden'));
        showMoreBtn.textContent = hiddenRows[0].classList.contains('hidden') ? 'Show More' : 'Show Less';
    });
});
</script>

<div class="row" style="position: relative; min-height: 1000px;">
    <div class="col-sm-3"></div>
    <div class="col-sm-7">
        <br><br>
        <form id="redeemForm" action="{{ route('UredeemPoint') }}" method="post">
            @csrf
            <input type="hidden" name="voucher_id" id="voucherIdInput" value="">
            <div class="form-group">
                <h3 for="points">Your Points:</h3>
                <h1 id="points">{{ $userPoints }}</h1>
            </div>

            <div class="row">
                <div class="col-sm-12">
                    <br><br>
                    <h3>Redemption</h3>
                </div>
            </div>
            <div class="row">
                @foreach($vouchers as $voucher)
                    <div class="col-sm-6">
                        <div class="card redeem-card" data-voucher-id="{{ $voucher->id }}" data-points="{{ $voucher->points_required }}">
                            <div class="card-body">
                                <h5 class="card-title">{{ $voucher->name }}</h5>
                                <p class="card-text">{{ $voucher->points_required }} Points - Discount: RM{{ $voucher->discount }}</p>
                                <button class="btn btn-primary redeem-button" type="button">Redeem</button>
                            </div>
                        </div>
                        <br>
                    </div>
                @endforeach
            </div>
        </form>

        @if (session('success'))
            <p class="alert alert-success">{{ session('success') }}</p>
        @endif

        @if ($errors->any())
            <p class="alert alert-danger">{{ $errors->first() }}</p>
        @endif

        <br><br><br><br>
        <h3>Point Transactions</h3>
        <table class="table">
    <thead>
        <tr>
            <th>Description</th>
            <th>Points Changed</th>
            <th>Discount (RM)</th>
            <th>Transaction Type</th>
            <th>Date</th>
        </tr>
    </thead>
    <tbody>
        @php
            $transactionsToShow = $transactions->take(3);
            $hiddenTransactions = $transactions->skip(3);
        @endphp

        @foreach ($transactionsToShow as $transaction)
            <tr>
                <td>{{ $transaction->description }}</td>
                <td>{{ $transaction->points_changed }}</td>
                <td>{{ $transaction->discount }}</td>
                <td>{{ ucfirst($transaction->transaction_type) }}</td>
                <td>{{ $transaction->created_at->format('Y-m-d H:i') }}</td>
            </tr>
        @endforeach

        @foreach ($hiddenTransactions as $transaction)
            <tr class="transaction-row hidden">
                <td>{{ $transaction->description }}</td>
                <td>{{ $transaction->points_changed }}</td>
                <td>{{ $transaction->discount }}</td>
                <td>{{ ucfirst($transaction->transaction_type) }}</td>
                <td>{{ $transaction->created_at->format('Y-m-d H:i') }}</td>
            </tr>
        @endforeach
    </tbody>
</table>
        <button id="showMoreBtn" class="show-more-btn">Show More</button>
    </div>
</div>

@endsection