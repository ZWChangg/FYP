@extends('layout')
@section('content')
<div class="row">
    <div class="col-sm-1"></div>
    <div class="col-sm-10">
        <br><br>
        <!-- User Filter Form -->
        <form action="{{ route('showAppointment') }}" method="GET" class="form-inline mb-3">
            <label for="userSelect" class="mr-2">Select User:</label>
            <select name="user_id" id="userSelect" class="form-control mr-2">
                <option value="">All Users</option>
                @foreach($users as $user)
                    <option value="{{ $user->id }}" {{ $user->id == $selectedUser ? 'selected' : '' }}>
                        {{ $user->name }}
                    </option>
                @endforeach
            </select>
            <button type="submit" class="btn btn-primary">Filter</button>
        </form>
        <br><br>

        <!-- Display Appointments Grouped by Date -->
        @foreach($appointments->groupBy('date') as $date => $dailyAppointments)
            <h3>{{ $date }}</h3>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <td>ID</td>
                        <td>Time</td>
                        <td>Phone Number</td>
                        <td>Outlet</td>
                        <td>Service</td>
                        <td>Barber</td>
                        <td>Voucher</td>
                        <td>Total Price</td>
                        <td>Total Time</td>
                        <td>Action</td>
                    </tr>
                </thead>
                <tbody>
                    @foreach($dailyAppointments as $appointment)
                    <tr>
                        <td>{{ $appointment->id }}</td>
                        <td>{{ $appointment->time }}</td>
                        <td>{{ $appointment->phoneNumber }}</td>
                        <td>{{ $appointment->outlet }}</td>
                        <td>
                            @php
                                $servicesWithDetails = json_decode($appointment->service, true);
                                $serviceNames = [];

                                if (json_last_error() === JSON_ERROR_NONE && is_array($servicesWithDetails)) {
                                    $serviceNames = array_map(function($service) {
                                        return isset($service['name']) ? $service['name'] : 'Unknown Service';
                                    }, $servicesWithDetails);
                                } else {
                                    $serviceNames[] = 'Invalid service data';
                                }
                            @endphp
                            {!! implode('<br>', $serviceNames) !!}
                        </td>
                        <td>
                            @if($appointment->barber)
                                {{ $appointment->barber->name }}
                                <img src="{{ asset('images/' . $appointment->barber->image) }}" alt="{{ $appointment->barber->name }}" width="50">
                            @else
                                Not Assigned
                            @endif
                        </td>
                        <td>
                            @if($appointment->redeemedVouchers->isNotEmpty())
                                @foreach($appointment->redeemedVouchers as $redeemedVoucher)
                                    @if($redeemedVoucher->voucher)
                                        {{ $redeemedVoucher->voucher->name }}
                                    @else
                                        No Voucher
                                    @endif
                                @endforeach
                            @else
                                No Voucher
                            @endif
                        </td>
                        <td>RM{{ $appointment->totalPrice }}</td>
                        <td>{{ intdiv($appointment->totalTime, 60) }} hrs {{ $appointment->totalTime % 60 }} mins</td>
                        <td>
                            <a href="{{ route('editAppointment', ['id' => $appointment->id]) }}" class="btn btn-warning btn-xs">Edit</a>
                            <a href="{{ route('deleteAppointment', ['id' => $appointment->id]) }}" class="btn btn-danger btn-xs" onClick="return confirm('Are you sure to delete this appointment?')">Delete</a>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
            <br>
        @endforeach
    </div>
    <div class="col-sm-1"></div>
</div>
@endsection