@extends('layout')
@section('content')
<style>
    .barber-card {
        display: flex;
        align-items: center;
        justify-content: space-between;
        border: none;
        background: none;
        height: 100%;
        text-align: left;
        padding: 10px;
        position: relative; /* 确保内部元素的绝对定位基于此容器 */
    }
    .barber-card img {
        width: 100px; /* 固定图片宽度 */
        height: 100px; /* 固定图片高度 */
        object-fit: cover; /* 保持图片比例并裁剪 */
        margin-left: 10px; /* 为图片添加左边距 */
    }
    .barber-card .card-title,
    .barber-card .card-text,
    .barber-card a {
        margin: 5px 0;
    }
    .barber-card-container {
        display: flex;
        flex-direction: column;
        height: 100%;
    }
    .form-check-input-barber {
        margin-right: 10px; /* 为 radio button 添加右边距 */
    }
    .form-check-label-barber {
        flex-grow: 1; /* 让标签占据剩余空间 */
        display: flex;
        flex-direction: column;
        align-items: center;
    }
    .barber-status {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        text-align: center;
        background-color: rgba(255, 255, 255, 0.7); /* 半透明背景 */
        padding: 5px 0;
        color: red;
    }
    .disabled img {
        filter: grayscale(100%); /* 变为灰色 */
    }
</style>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const checkboxes = document.querySelectorAll('.form-check-input[type="checkbox"]');
    const totalPriceDisplay = document.getElementById('totalPriceDisplay');
    const totalPriceInput = document.getElementById('totalPrice');
    const totalTimeDisplay = document.getElementById('totalTimeDisplay');
    const totalTimeInput = document.getElementById('totalTime');
    const endTimeDisplay = document.getElementById('endTimeDisplay');
    const services = @json($services);
    const barbers = @json($barbers);
    const vouchers = @json($redeemedVouchers);
    const barberRadioButtons = document.querySelectorAll('input[name="barberID"]');
    const dateInput = document.getElementById('date');
    const timeSelect = document.getElementById('time');
    const voucherSelect = document.getElementById('voucherSelect');

    function formatTime(hours, minutes) {
        return String(hours).padStart(2, '0') + ':' + String(minutes).padStart(2, '0');
    }

    function updateTotalPriceAndTime() {
        let total = 0;
        let totalTime = 0;

        // Add service costs and durations
        checkboxes.forEach((checkbox) => {
            if (checkbox.checked) {
                const service = services.find(service => service.id == checkbox.value);
                if (service) {
                    total += parseFloat(service.cost);
                    totalTime += parseInt(service.duration);
                }
            }
        });

        // Add barber cost (no duration for barber)
        barberRadioButtons.forEach((radio) => {
            if (radio.checked) {
                const barber = barbers.find(barber => barber.id == radio.value);
                if (barber) {
                    total += parseFloat(barber.cost);
                }
            }
        });

        // Apply voucher discount
        const selectedVoucherId = voucherSelect.value;
            if (selectedVoucherId) {
                const voucher = vouchers.find(v => v.id == selectedVoucherId);
                if (voucher && voucher.discount) {
                    total -= parseFloat(voucher.discount);
                }
            }

        const hours = Math.floor(totalTime / 60);
        const minutes = totalTime % 60;

        // Update total price display
        totalPriceDisplay.textContent = 'Total Price: RM' + total.toFixed(2) + ' ++';
        totalPriceInput.value = total.toFixed(2);

        // Update total time display
        totalTimeDisplay.textContent = 'Total Time Spent: ' + hours + ' hrs ' + minutes + ' mins';
        totalTimeInput.value = totalTime;

        // Calculate and update end time
        const startTime = timeSelect.value.split(':');
        let endHours = parseInt(startTime[0]) + hours;
        let endMinutes = parseInt(startTime[1]) + minutes;

        if (endMinutes >= 60) {
            endMinutes -= 60;
            endHours += 1;
        }

        endTimeDisplay.textContent = 'End Time: ' + formatTime(endHours, endMinutes);
    }

    function updateDateConstraints() {
        const today = new Date();
        const yyyy = today.getFullYear();
        const mm = String(today.getMonth() + 1).padStart(2, '0');
        const dd = String(today.getDate()).padStart(2, '0');
        const minDate = `${yyyy}-${mm}-${dd}`;
        dateInput.setAttribute('min', minDate);
    }

    function updateTimeOptions() {
        const selectedDate = new Date(dateInput.value);
        const now = new Date();
        let minTime = '09:00';
        let maxTime = '20:30';

        if (selectedDate.toDateString() === now.toDateString()) {
            const hours = now.getHours();
            const minutes = now.getMinutes();

            if (minutes < 30) {
                minTime = formatTime(hours, 30);
            } else {
                minTime = formatTime(hours + 1, 0);
            }
        }

        generateTimeOptions(minTime, maxTime);
    }

    function generateTimeOptions(minTime, maxTime) {
        timeSelect.innerHTML = '';
        const [minHours, minMinutes] = minTime.split(':').map(Number);
        const [maxHours, maxMinutes] = maxTime.split(':').map(Number);

        for (let hour = 9; hour <= 20; hour++) {
            ['00', '30'].forEach(min => {
                if (
                    (hour > minHours) ||
                    (hour === minHours && min >= minMinutes) ||
                    (hour === maxHours && min <= maxMinutes)
                ) {
                    const option = document.createElement('option');
                    option.value = formatTime(hour, min);
                    option.textContent = formatTime(hour, min);
                    timeSelect.appendChild(option);
                }
            });
        }
    }

    function checkBarberAvailability() {
        const date = dateInput.value;
        const time = timeSelect.value;
        const selectedServices = Array.from(checkboxes)
            .filter(checkbox => checkbox.checked)
            .map(checkbox => checkbox.value);

        if (date && time) {
            fetch('{{ route('checkBarberAvailability') }}', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                },
                body: JSON.stringify({ date, time, services: selectedServices })
            })
            .then(response => response.json())
            .then(data => {
                barberRadioButtons.forEach(radio => {
                    const card = radio.parentElement.querySelector('.image-container');
                    if (data.unavailableBarbers.includes(parseInt(radio.value))) {
                        radio.disabled = true;
                        radio.parentElement.classList.add('text-muted');
                        card.classList.add('disabled');
                        let warning = card.querySelector('.barber-status');
                        if (!warning) {
                            warning = document.createElement('span');
                            warning.classList.add('text-danger', 'barber-status');
                            warning.textContent = 'Busy';
                            card.appendChild(warning);
                        }
                    } else {
                        radio.disabled = false;
                        radio.parentElement.classList.remove('text-muted');
                        card.classList.remove('disabled');
                        const warning = card.querySelector('.barber-status');
                        if (warning) {
                            warning.remove();
                        }
                    }
                });
            });
        }
    }

    checkboxes.forEach(checkbox => {
        checkbox.addEventListener('change', () => {
            updateTotalPriceAndTime();
            checkBarberAvailability();
        });
    });

    barberRadioButtons.forEach(radio => {
        radio.addEventListener('change', () => {
            updateTotalPriceAndTime();
            checkBarberAvailability();
        });
    });

    voucherSelect.addEventListener('change', () => {
        updateTotalPriceAndTime();
    });

    dateInput.addEventListener('change', () => {
        updateTimeOptions();
        checkBarberAvailability();
    });

    timeSelect.addEventListener('change', () => {
        updateTotalPriceAndTime();
        checkBarberAvailability();
    });

    updateTotalPriceAndTime(); // Initialize total price and time
    updateDateConstraints(); // Initialize date constraints
    updateTimeOptions(); // Initialize time options
});
</script>

<div class="container">
    <h3 style="text-align: center;">Edit Appointment</h3><br>
    <form action="{{ route('updateAppointment') }}" method="post" enctype='multipart/form-data'>
        @csrf
        <input type="hidden" name="id" value="{{ $appointment->id }}">
        
        <div class="form-group">
            <label for="date">Date:</label>
            <input class="form-control" type="date" id="date" name="date" required value="{{ $appointment->date }}">
        </div>

        <div class="form-group">
            <label for="time">Time:</label>
            <select class="form-control" id="time" name="time" required>
                <option value="{{ $appointment->time }}" selected>{{ $appointment->time }}</option>
            </select>
        </div>

        <div class="form-group">
            <label for="phoneNumber">Phone Number:</label>
            <input class="form-control" type="text" id="phoneNumber" name="phoneNumber" required value="{{ $appointment->phoneNumber }}">
        </div>

        <div class="form-group">
            <label for="outlet">Outlet:</label>
            <input class="form-control" type="text" id="outlet" name="outlet" required value="{{ $appointment->outlet }}">
        </div>

        <div class="form-group">
            <label for="service">Services:</label><br>
            @foreach($services as $service)
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="service{{ $service->id }}" name="service[]" value="{{ $service->id }}"
                        {{ in_array($service->id, array_column(json_decode($appointment->service, true), 'id')) ? 'checked' : '' }}>
                    <label class="form-check-label" for="service{{ $service->id }}">
                        {{ $service->name }} - RM{{ $service->cost }} - {{ $service->duration }} minutes
                    </label>
                </div>
            @endforeach
        </div>
        
        <div class="form-group">
            <label for="barber">Choose a Barber:</label>
            <div class="form-row">
            @foreach($barbers as $barber)
            <div class="col-md-4">
                <div class="form-check">
                    <input class="form-check-input" type="radio" id="barber{{ $barber->id }}" name="barberID" value="{{ $barber->id }}" {{ $appointment->barber_id == $barber->id ? 'checked' : '' }} required>
                    <label class="form-check-label" for="barber{{ $barber->id }}">
                        <img src="{{ asset('images/' . $barber->image) }}" alt="{{ $barber->name }}" width="100">
                        <br>{{ $barber->name }} - RM{{ $barber->cost }}
                    </label>
                </div>
            </div>
            @endforeach
            </div>
        </div>

        <div class="form-group">
            <label for="voucherSelect">Redeemed Vouchers:</label>
            <select class="form-control" id="voucherSelect" name="voucher">
                <option value="">None</option>
                @foreach ($redeemedVouchers as $voucher)
                    <option value="{{ $voucher->id }}" 
                        {{ $voucher->id == $appointment->voucher_id ? 'selected' : '' }}>
                        {{ $voucher->voucher->name }} - RM{{ $voucher->voucher->discount }}
                    </option>
                @endforeach
            </select>
        </div>

        <div class="form-group">
            <p id="totalPriceDisplay">Total Price: RM{{ $appointment->totalPrice }}</p>
            <input type="hidden" id="totalPrice" name="totalPrice" value="{{ $appointment->totalPrice }}">
        </div>

        <div class="form-group">
            <p id="totalTimeDisplay">Total Time Spent: {{ floor($appointment->totalTime / 60) }} hrs {{ $appointment->totalTime % 60 }} mins</p>
            <input type="hidden" id="totalTime" name="totalTime" value="{{ $appointment->totalTime }}">
        </div>

        <button class="btn btn-outline-primary" type="submit">Update</button>
    </form>
    <br><br>
</div>
@endsection