@extends('layout')
@section('content')

<div class="container">
    <h1>Edit Voucher</h1>
    <form action="{{ route('updateVoucher', $voucher->id) }}" method="post">
        @csrf   
        <div class="form-group">
            <label for="name">Voucher Name</label>
            <input type="text" class="form-control" id="name" name="name" value="{{ $voucher->name }}" required>
        </div>
        <div class="form-group">
            <label for="discount">Discount</label>
            <input type="number" class="form-control" id="discount" name="discount" value="{{ $voucher->discount }}" step="0.01" required>
        </div>
        <div class="form-group">
            <label for="points_required">Points Required</label>
            <input type="number" class="form-control" id="points_required" name="points_required" value="{{ $voucher->points_required }}" required>
        </div>
        <div class="form-group">
            <label for="is_active">Is Active</label>
            <select class="form-control" id="is_active" name="is_active" required>
                <option value="1" {{ $voucher->is_active ? 'selected' : '' }}>Active</option>
                <option value="0" {{ !$voucher->is_active ? 'selected' : '' }}>Inactive</option>
            </select>
        </div>
        <button type="submit" class="btn btn-success">Update Voucher</button>
    </form>
</div>
@endsection
