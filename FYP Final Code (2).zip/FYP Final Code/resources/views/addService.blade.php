@extends('layout')
@section('content')
<script>
    function redirectToAnotherPage(viewPath) {
        window.location.href = viewPath;
    }
</script>
<div class="container">
    <h3 style="text-align: center;">Add New Service</h3><br>
    <form action="{{ route('addService.store') }}" method="post" enctype='multipart/form-data'>
        @csrf
        <div class="form-group">
            <label for="name">Name:</label>
            <input class="form-control" type="text" id="name" name="name" required>
        </div>
        <div class="form-group">
            <label for="duration">Duration (minutes):</label>
            <input class="form-control" type="number" id="duration" name="duration" required>
        </div>
        <div class="form-group">
            <label for="cost">Cost (RM):</label>
            <input class="form-control" type="number" id="cost" name="cost" min="0" required>
        </div>
        <div class="form-group">
            <label for="image">Image:</label>
            <input class="form-control" type="file" id="image" name="image" min="0" required>
        </div>

        <button type="submit" class="btn btn-outline-primary">Add Service</button>
    </form>
    <br><br>
</div>
@endsection
