@extends('layout')
@section('content')
<div class="row">
    <div class="col-sm-3"></div>
    <div class="col-sm-7">
        <br><br>
        <h3>Edit Barber</h3>
        <form action="{{ route('updateBarber', ['id' => $barber->id]) }}" method="post" enctype='multipart/form-data'>
            @csrf
            @method('PUT')
            <div class="form-group">
                <label for="barberName">Barber Name</label>
                <input class="form-control" type="text" id="barberName" name="barberName" value="{{ old('barberName', $barber->name) }}" required>
            </div>
            <div class="form-group">
                <label for="barberPhoneNo">Phone Number</label>
                <input class="form-control" type="text" id="barberPhoneNo" name="barberPhoneNo" value="{{ old('barberPhoneNo', $barber->phoneNo) }}" required>
            </div>
            <div class="form-group">
                <label for="barberEmail">Barber Email</label>
                <input class="form-control" type="text" id="barberEmail" name="barberEmail" value="{{ old('barberEmail', $barber->email) }}" required>
            </div>
            <div class="form-group">
                <label for="barberInfo">Barber Information</label>
                <input class="form-control" type="text" id="barberInfo" name="barberInfo" value="{{ old('barberInfo', $barber->information) }}" required>
            </div>
            <div class="form-group">
                <label for="barberImage">Image</label>
                <input class="form-control" type="file" id="barberImage" name="barberImage">
                @if($barber->image)
                    <img src="{{ asset('images/' . $barber->image) }}" alt="{{ $barber->name }}" width="100">
                @endif
            </div>
            <div class="form-group">
                <label for="barberCost">Barber Cost</label>
                <input class="form-control" type="number" id="barberCost" name="barberCost" step="0.01" value="{{ old('barberCost', $barber->cost) }}" required>
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
        </form>
        <br><br>
    </div>
    <div class="col-sm-3"></div>
</div>
@endsection