@extends('layout')

@section('content')

<div class="container">
    <h1>Edit Redeemed Voucher Record</h1>

    <form action="{{ route('updateRedeemedRecord', $redeemedVoucher->id) }}" method="POST">
        @csrf
        @method('PUT')

        <div class="form-group">
            <label for="is_used">Is Used:</label>
            <select class="form-control" id="is_used" name="is_used">
                <option value="1" {{ $redeemedVoucher->is_used ? 'selected' : '' }}>Yes</option>
                <option value="0" {{ !$redeemedVoucher->is_used ? 'selected' : '' }}>No</option>
            </select>
        </div>

        <div class="form-group">
            <label for="appointment_id">Appointment ID:</label>
            <input type="number" class="form-control" id="appointment_id" name="appointment_id" value="{{ $redeemedVoucher->appointment_id }}">
        </div>

        <button type="submit" class="btn btn-primary">Update</button>
        <a href="{{ route('redeemedRecord') }}" class="btn btn-secondary">Cancel</a>
    </form>
</div>

@endsection