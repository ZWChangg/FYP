@extends('layout')
@section('content')
<div class="row">
    <div class="col-sm-3"></div>
    <div class="col-sm-6">
        <br><br>
        <h3>Edit Service</h3>
        <form action="{{ route('updateService') }}" method="POST" enctype="multipart/form-data">
            @csrf
            @foreach($services as $service)
            <div class="form-group">
                <label for="name">Name</label>
                <input class="form-control" type="text" id="name" name="name" required value="{{ $service->name }}">
            </div>
            <div class="form-group">
            <label for="duration">Duration (minutes):</label>
            <input class="form-control" type="number" id="duration" name="duration" value="{{ $service->duration }}" required>
            </div>
            <div class="form-group">
                <label for="cost">Price (RM)</label>
                <input class="form-control" type="number" id="cost" name="cost" min="0" required value="{{ $service->cost }}">
            </div>
            <div class="form-group">
                <label for="image">Image</label>
                <input class="form-control" type="file" id="image" name="image">
                @if($service->image)
                    <img src="{{ asset('images/' . $service->image) }}" alt="{{ $service->image }}" width="100">
                @endif
            </div>
            <div class="form-group">
                <label for="services">Services:</label>
                    <ul id="services">
                        <li>{{ $service }}</li>
                    </ul>
            </div>
            <input type="hidden" name="id" value="{{ $service->id }}">
            <button type="submit" class="btn btn-outline-primary">Update</button>
            @endforeach
        </form>
        <br><br>
    </div>
    <div class="col-sm-3"></div>
</div>
@endsection
