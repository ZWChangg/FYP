@extends('Ulayout')
@section('content')

<div class="container">
    <div class="row">
        <div class="col-12">
            <button onclick="goBack()" class="btn btn-secondary mb-3">
                <i class="fas fa-arrow-left"></i> Go Back
            </button>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <h3>Barber Information</h3>
            <div class="card" style="background-color: rgba(255, 255, 255, 0.2);">
                <div class="card-body">
                    <h5 class="card-title">{{ $barber->name }}</h5>
                    <p><img src="{{ asset('images/' . $barber->image) }}" alt="{{ $barber->name }}" class="img-fluid" style="height:350px;text-align:center;object-fit: cover;"></p>
                    <p class="card-text">Phone: {{ $barber->phoneNo }}</p>
                    <p class="card-text">Email: {{ $barber->email }}</p>
                    <p class="card-text">Details: {{ $barber->information }}</p>
                    <p class="card-text">Cost: RM{{ $barber->cost }}</p>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <h4>{{ $barber->name }}'s Calendar</h4>
            <div id="calendar"></div>
        </div>
    </div>
</div>

<script>
    function goBack() {
        window.history.back();
    }

    document.addEventListener('DOMContentLoaded', function() {
        const calendarEl = document.getElementById('calendar');

        const calendar = new FullCalendar.Calendar(calendarEl, {
            initialView: 'dayGridMonth',
            events: [], // Initialize with empty events
            eventClick: function(info) {
                const details = info.event.extendedProps.details;
                const detailString = `Barber name: ${details.barber_name}\nTime: ${details.time}\nEnd time: ${details.end_time}`;
                document.getElementById('eventDetails').textContent = detailString;
                $('#eventDetailsModal').modal('show');
            }
        });
    
        document.addEventListener('DOMContentLoaded', function() {
    // 从本地存储加载数据
            const savedTotalPrice = localStorage.getItem('totalPrice');
            const savedTotalTime = localStorage.getItem('totalTime');
            const savedEndTime = localStorage.getItem('endTime');

            if (savedTotalPrice) {
                document.getElementById('totalPrice').value = savedTotalPrice;
                document.getElementById('totalPriceDisplay').textContent = 'Total Price: RM' + savedTotalPrice + '++';
            }

            if (savedTotalTime) {
                document.getElementById('totalTime').value = savedTotalTime;
                const totalTime = parseInt(savedTotalTime, 10);
                const hours = Math.floor(totalTime / 60);
                const minutes = totalTime % 60;
                document.getElementById('totalTimeDisplay').textContent = 'Total Time Spent: ' + hours + ' hrs ' + minutes + ' mins';
            }

            if (savedEndTime) {
                document.getElementById('endTimeDisplay').textContent = 'End Time: ' + savedEndTime;
            }

            // 保存数据到本地存储
            function saveData() {
                localStorage.setItem('totalPrice', document.getElementById('totalPrice').value);
                localStorage.setItem('totalTime', document.getElementById('totalTime').value);
                localStorage.setItem('endTime', document.getElementById('endTimeDisplay').textContent.replace('End Time: ', ''));
            }

            // 在相关操作后保存数据
            checkboxes.forEach(checkbox => {
                checkbox.addEventListener('change', () => {
                    updateTotalPriceAndTime();
                    saveData();
                });
            });

            barberRadioButtons.forEach(radio => {
                radio.addEventListener('change', () => {
                    updateTotalPriceAndTime();
                    saveData();
                });
            });

            dateInput.addEventListener('change', () => {
                updateTimeOptions();
                saveData();
            });

            timeSelect.addEventListener('change', () => {
                updateTotalPriceAndTime();
                saveData();
            });
        });


    calendar.render();

    // Fetch the barber's schedule and add to the calendar
    fetch(`/calendarData/{{ $barber->id }}`)
        .then(response => response.json())
        .then(schedules => {
            console.log(schedules);
            calendar.removeAllEvents();
            calendar.addEventSource(schedules);
        });
});
</script>

<div class="modal fade" id="eventDetailsModal" tabindex="-1" role="dialog" aria-labelledby="eventDetailsModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="eventDetailsModalLabel" style="color:black">Appointment Details</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <pre id="eventDetails"></pre>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<style>
    .fc-toolbar .fc-button {
        font-size: 18px;
        padding: 20px;
        display: flex;
        justify-content: center;
        align-items: center;
        line-height: 2;
    }

    body {
        background-size: cover;
        background-position: center;
        background-color: rgba(0, 0, 0, 0.7);
        background-blend-mode: overlay;
        width: 100%;
        color: white;
    }
    .container {
        background-color: rgba(0, 0, 0, 0.5); 
        padding: 20px;
        border-radius: 10px;
    }
</style>

@endsection
