@extends('layout')

@section('content')

<br>
<div class="container">
    <h1>Redeemed Voucher Records</h1>

    <table class="table">
        <thead>
            <tr>
                <th>User Name</th>
                <th>Voucher Name</th>
                <th>Redeemed At</th>
                <th>Is Used</th>
                <th>Appointment ID</th> <!-- New column -->
                <th>Actions</th> <!-- Add an actions column -->
            </tr>
        </thead>
        <tbody>
            @foreach($redeemedVouchers as $redeemedVoucher)
                <tr>
                    <td>{{ $redeemedVoucher->user->name }}</td>
                    <td>{{ $redeemedVoucher->voucher->name }}</td>
                    <td>{{ $redeemedVoucher->created_at->format('Y-m-d H:i') }}</td>
                    <td>{{ $redeemedVoucher->is_used ? 'Yes' : 'No' }}</td>
                    <td>{{ $redeemedVoucher->appointment ? $redeemedVoucher->appointment->id : 'N/A' }}</td>
                    <td>
                        <a href="{{ route('editRedeemedRecord', $redeemedVoucher->id) }}" class="btn btn-warning btn-sm">Edit</a>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>

@endsection
