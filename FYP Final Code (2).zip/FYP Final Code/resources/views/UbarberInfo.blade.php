@extends('Ulayout')

@section('content')
<div class="row">
    <div class="col-sm-2"></div>
    <div class="col-sm-8" style="color:white;">
        <br><br>
        <div class="d-flex align-items-center mb-3">
            <h3 class="mr-3">Barber Information</h3>
            <a href="UbarberCalendar" class="btn btn-black btn-square">
                <img src="{{ asset('images/calendar.jpeg') }}" alt="Button Image" class="img-fluid">
            </a>
        </div>
        @foreach($barbers as $barber)
        <div class="card mb-3">
            <div class="card-header">
                {{ $barber->name }}
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-sm-4">
                        @if($barber->image)
                            <img src="{{ asset('images/' . $barber->image) }}" alt="{{ $barber->name }}" class="img-fluid" style="width:260px;height:230px;">
                        @else
                            <img src="{{ asset('images/empty.jpg') }}" alt="No Image" class="img-fluid">
                        @endif
                    </div>
                    <div class="col-sm-8">
                        <p><strong>Phone Number:</strong> {{ $barber->phoneNo }}</p>
                        <p><strong>Email:</strong> {{ $barber->email }}</p>
                        <p><strong>Information:</strong> {{ $barber->information }}</p>
                        <p><strong>Cost:</strong> RM{{ $barber->cost }}</p>
                    </div>
                </div>
            </div>
        </div>
        @endforeach
    </div>
    <div class="col-sm-2"></div>
</div>

<style>
    body {
        background-image: url('images/shop2.jpg');
        background-size: cover;
        background-position: center;
        background-color: rgba(0, 0, 0, 0.7);
        background-blend-mode: overlay;
        width: 100%;
    }
    .card {
        margin-bottom: 10px;
        height: 330px;
        background-color: rgba(255, 255, 255, 0.2);
    }
    .btn-square {
        height: 40px; 
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 0;
        border-radius: 8px; /* Make sure the button is square */
        overflow: hidden; /* Hide any overflow of the image */
        position: relative; /* Make sure the image can be absolutely positioned inside */
    }
    .btn-square img {
        width: 100%; /* Make the image cover the width of the button */
        height: 100%; /* Make the image cover the height of the button */
        object-fit: cover; /* Ensure the image covers the button while maintaining its aspect ratio */
    }
</style>
@endsection
