<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/barberInfo', [App\Http\Controllers\barberController::class, 'view'])->name('barberInfo');
Route::get('/addbarber/{id}',[App\Http\Controllers\barberController::class, 'add'])->name('barberID');
Route::get('/addbarber',function () {return view('addbarber');})->name('addbarber');
Route::post('/addbarber/store', [App\Http\Controllers\barberController::class, 'add'])->name('addbarber.store');
Route::put('/updateBarber/{id}', [App\Http\Controllers\BarberController::class, 'update'])->name('updateBarber');
Route::get('/deletebarber/{id}', [App\Http\Controllers\barberController::class, 'delete'])->name('deletebarber');
Route::get('/editbarber/{id}', [App\Http\Controllers\barberController::class, 'edit'])->name('editbarber');
Route::get('/admin/login', [AdminController::class, 'showLoginForm'])->name('admin.login.form');
Route::post('/admin/login', [AdminController::class, 'login'])->name('admin.login');
Route::get('/addService', function() { return view('addService'); })->name('addService');
Route::post('/addService/store', [App\Http\Controllers\ServiceController::class, 'add'])->name('addService.store');
Route::get('/showService',[App\Http\Controllers\ServiceController::class,'view'])->name('showService');
Route::get('/editService/{id}',[App\Http\Controllers\ServiceController::class,'edit'])->name('editService');
Route::post('/updateService',[App\Http\Controllers\ServiceController::class,'update'])->name('updateService');
Route::get('/deleteService/{id}', [App\Http\Controllers\ServiceController::class,'delete'])->name('deleteService');
Route::get('/showAppointment',[App\Http\Controllers\AppointmentController::class,'view'])->name('showAppointment');
Route::get('/editAppointment/{id}',[App\Http\Controllers\AppointmentController::class,'edit'])->name('editAppointment');
Route::post('/updateAppointment',[App\Http\Controllers\AppointmentController::class,'update'])->name('updateAppointment');
Route::get('/deleteAppointment/{id}', [App\Http\Controllers\AppointmentController::class,'delete'])->name('deleteAppointment');
Route::get('/appointmentHistory', [App\Http\Controllers\AppointmentController::class, 'history'])->name('appointmentHistory');
Route::get('addPoint', [App\Http\Controllers\PointController::class, 'showAddForm'])->name('addPoint');
Route::get('showPoint', [App\Http\Controllers\PointController::class, 'view'])->name('showPoint');
Route::post('addPoint/{user}', [App\Http\Controllers\PointController::class, 'add'])->name('addPointt');
Route::post('subPoint/{user}', [App\Http\Controllers\PointController::class, 'sub'])->name('subPoint');
Route::get('addVoucher', [App\Http\Controllers\VoucherController::class, 'showAddForm'])->name('addVoucher');
Route::post('addVoucher', [App\Http\Controllers\VoucherController::class, 'add'])->name('storeVoucher');
Route::get('editVoucher/{id}', [App\Http\Controllers\VoucherController::class, 'edit'])->name('editVoucher');
Route::post('updateVoucher/{id}', [App\Http\Controllers\VoucherController::class, 'update'])->name('updateVoucher');
Route::get('deleteVoucher/{id}', [App\Http\Controllers\VoucherController::class, 'delete'])->name('deleteVoucher');
Route::get('showVoucher', [App\Http\Controllers\VoucherController::class, 'view'])->name('showVoucher');
Route::get('redeemedRecord', [App\Http\Controllers\VoucherController::class, 'showAllRedeemedRecord'])->name('redeemedRecord');
Route::get('editRedeemedRecord/{id}', [App\Http\Controllers\VoucherController::class, 'editRD'])->name('editRedeemedRecord');
Route::put('updateRedeemedRecord/{id}', [App\Http\Controllers\VoucherController::class, 'updateRD'])->name('updateRedeemedRecord');

Route::get('/UbarberInfo', [App\Http\Controllers\barberController::class, 'Uview'])->name('UbarberInfo');
Route::get('/UaddAppointment', function(){ return view('UaddAppointment');})->name('UaddAppointment');
Route::get('/UaddAppointment/{id}',[App\Http\Controllers\AppointmentController::class,'add'])->name('appiontmentID');
Route::get('/UaddAppointment', [App\Http\Controllers\AppointmentController::class, 'showAddForm'])->name('UaddAppointmentt');
Route::post('/UaddAppointment/store', [App\Http\Controllers\AppointmentController::class, 'add'])->name('UaddAppointment.store');
Route::get('/UshowAppointment',[App\Http\Controllers\AppointmentController::class,'viewU'])->name('UshowAppointment');
Route::get('/UeditAppointment/{id}',[App\Http\Controllers\AppointmentController::class,'Uedit'])->name('UeditAppointment');
Route::post('/updateAppointmentU',[App\Http\Controllers\AppointmentController::class,'updateU'])->name('updateAppointmentU');
Route::get('/UdeleteAppointment/{id}', [App\Http\Controllers\AppointmentController::class,'deleteU'])->name('UdeleteAppointment');
Route::post('/check-barber-availability', [App\Http\Controllers\AppointmentController::class, 'checkBarberAvailability'])->name('checkBarberAvailability');
Route::get('/UappointmentHistory', [App\Http\Controllers\AppointmentController::class, 'Uhistory'])->name('UappointmentHistory');
Route::get('/UaboutUs', [App\Http\Controllers\ServiceController::class,'aboutUs'])->name('UaboutUs');
Route::get('/UshowService', [App\Http\Controllers\ServiceController::class,'Uview'])->name('UshowService');
Route::get('UbarberCalendar', [App\Http\Controllers\AppointmentController::class, 'showCalendar'])->name('UbarberCalendar');
Route::get('calendarData/{barberId}', [App\Http\Controllers\AppointmentController::class, 'getCalendarData'])->name('calendarData');
Route::get('/UbarberDetail/{id}', [App\Http\Controllers\barberController::class, 'showDetails'])->name('UbarberDetail');
Route::get('UredeemPoint', [App\Http\Controllers\PointController::class, 'showRedeemPoints'])->name('UredeemPoint');
Route::post('UredeemPoint', [App\Http\Controllers\PointController::class, 'redeemPoints'])->name('redeemPoint.submit');

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
