<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RedeemedVoucher extends Model
{
    // 指定表名
    protected $table = 'redeemed_vouchers';

    // 指定可填充属性
    protected $fillable = [
        'user_id',     // 用户ID
        'voucher_id',  // 关联的Voucher ID
        'discount',    // 折扣金额或百分比
        'is_used'      // 代金券是否已使用
    ];

    public function appointment()
{
    return $this->belongsTo(Appointment::class);
}

public function voucher()
{
    return $this->belongsTo(Voucher::class);
}

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

}