<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Appointment extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'date',
        'time',
        'phoneNumber',
        'outlet',
        'service',
        'totalPrice',
        'totalTime',
        'barber_id',
        'status',
        'booked', // Ensure 'booked' is included
        'details', // Ensure 'details' is included
        'endTime',
        'voucher_id',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function barber() {
        return $this->belongsTo(Barber::class);
    }
    public function voucher()
    {
        return $this->belongsTo(Voucher::class, 'voucher_id');
    }

    public function redeemedVouchers()
    {
        return $this->hasMany(RedeemedVoucher::class);
    }
}
