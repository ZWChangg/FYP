<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Voucher extends Model
{
    // 指定表名
    protected $table = 'vouchers';

    // 指定可填充属性
    protected $fillable = [
        'name',
        'discount', // 折扣金额或百分比
        'is_active', // 代金券是否激活
        'points_required' // Points required for the voucher
    ];

    // 定义与 RedeemedVoucher 的关系
    public function redeemedVouchers()
    {
        return $this->hasMany(RedeemedVoucher::class, 'voucher_id');
    }

    public function appointments()
    {
        return $this->hasMany(Appointment::class, 'voucher_id');
    }
}
