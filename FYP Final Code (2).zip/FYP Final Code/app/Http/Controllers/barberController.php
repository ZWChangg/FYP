<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Barber;
use App\Models\Service;
use App\Models\Appointment;
use Session;

class BarberController extends Controller
{
    public function view()
    {
        $viewBarber = Barber::all();
        return view('barberInfo')->with('barbers', $viewBarber);
    }

    public function Uview()
    {
        $viewBarber = Barber::all();
        return view('UbarberInfo')->with('barbers', $viewBarber);
    }

    public function add(Request $request)
    {
        $imageName = "empty.jpg";
        if ($request->hasFile('barberImage')) {
            $image = $request->file('barberImage');
            $imageName = time() . '_' . $image->getClientOriginalName();
            $image->move(public_path('images'), $imageName);
        }

        Barber::create([
            'name' => $request->barberName,
            'phoneNo' => $request->barberPhoneNo,
            'email' => $request->barberEmail,
            'information' => $request->barberInfo,
            'image' => $imageName,
            'cost' => $request->barberCost,
        ]);

        return redirect()->route('barberInfo')->with('success', 'Barber added successfully!');
    }

    public function edit($id)
    {
        $barber = Barber::find($id);
        if (!$barber) {
            return redirect()->route('barberInfo')->with('error', 'Barber not found');
        }
        return view('editBarber', compact('barber'));
    }

    public function delete($id){
        $barber=Barber::find($id);
        $barber->delete();//SQL "delete from products where id='$id'"
        Session::flash('success',"Barber deleted");
        return redirect()->route('barberInfo');
    }

    public function update(Request $request, $id)
{
    $barber = Barber::find($id);

    if (!$barber) {
        return redirect()->route('barberInfo')->with('error', 'Barber not found');
    }

    if ($request->hasFile('barberImage')) {
        $image = $request->file('barberImage');
        $imageName = time() . '_' . $image->getClientOriginalName();
        $image->move(public_path('images'), $imageName);
        $barber->image = $imageName;
    }

    $barber->name = $request->barberName;
    $barber->phoneNo = $request->barberPhoneNo;
    $barber->email = $request->barberEmail;
    $barber->information = $request->barberInfo;
    $barber->cost = $request->barberCost;
    $barber->save();

    return redirect()->route('barberInfo')->with('success', 'Barber updated successfully!');
}


    public function show($id)
    {
        $barber = Barber::find($id);

        if (!$barber) {
            return redirect()->route('barberInfo')->with('error', 'Barber not found');
        }

        return view('barberInfo', compact('barber'));
    }

    public function showDetails($id)
    {
        $barber = Barber::findOrFail($id);
        $appointments = Appointment::where('barber_id', $id)->get();

        return view('UbarberDetail', compact('barber', 'appointments'));
    }


}