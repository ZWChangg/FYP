<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Models\RedeemedVoucher;
use App\Models\Appointment;
use App\Models\Service;
use App\Models\Barber;
use App\Models\Point;
use App\Models\User;
use App\Models\Voucher;
use Carbon\Carbon;
use Session;
use DB;

class AppointmentController extends Controller
{
    public function add(Request $request) {
        $validatedData = $request->validate([
            'date' => 'required|date',
            'time' => 'required',
            'barberID' => 'required|exists:barbers,id',
            'service' => 'required|array',
            'service.*' => 'exists:services,id',
            'voucher' => 'nullable|exists:redeemed_vouchers,id',
            'phoneNumber' => 'required|string',
            'outlet' => 'required|string',
            
        ]);
        $selectedServices = Service::whereIn('id', $request->service)->get();
        $servicesWithDetails = $selectedServices->map(function($service) {
            return [
                'id' => $service->id,
                'name' => $service->name,
                'cost' => $service->cost,
                'duration' => $service->duration
            ];
        })->toArray();
    
        $totalPrice = array_sum(array_column($servicesWithDetails, 'cost'));
        $totalTime = array_sum(array_column($servicesWithDetails, 'duration'));
    
        $barberId = $request->input('barberID');
        $barber = Barber::find($barberId);
        $barberCost = $barber ? $barber->cost : 0;
        $totalPrice += $barberCost;
        
        $voucherId = $request->input('voucher');
        $redeemedVouchers = null;
        if ($voucherId) {
            $redeemedVouchers = RedeemedVoucher::where('id', $voucherId)
                                              ->where('user_id', auth()->id())
                                              ->where('is_used', false)
                                              ->first();
    
            if ($redeemedVouchers) {
                // Apply the voucher discount
                $totalPrice -= $redeemedVouchers->voucher->discount;
                $totalPrice = max($totalPrice, 0);
            } else {
                return redirect()->back()->withErrors('Invalid or already used voucher');
            }
        }

        $startTime = Carbon::parse($request->time);
        $endTime = $startTime->copy()->addMinutes($totalTime);
    
        $appointment = Appointment::create([
            'date' => $request->date,
            'time' => $request->time,
            'endTime' => $endTime->format('H:i:s'),
            'phoneNumber' => $request->phoneNumber,
            'outlet' => $request->outlet,
            'service' => json_encode($servicesWithDetails),
            'totalPrice' => $totalPrice,
            'totalTime' => $totalTime,
            'barber_id' => $request->barberID,
            'voucher_id' => $redeemedVouchers ? $voucherId : null,
            'user_id' => auth()->id(),
        ]);

        $appointment->user()->associate(auth()->user());
        $appointment->save();

        if ($redeemedVouchers) {
            $redeemedVouchers->is_used = true;
            $redeemedVouchers->appointment_id = $appointment->id;
            $redeemedVouchers->save();
        }
    
        // Add points logic
        $user = auth()->user();
        if ($user) {
            $earnedPoints = ceil($totalPrice); // 1 point for every RM1 spent
            $user->points += $earnedPoints;
            $user->save();
        } else {
            return redirect()->route('UshowAppointment')->with('error', 'User not authenticated');
        }
    
        return redirect()->route('UshowAppointment')->with('success', 'Appointment added successfully!');
    }        

public function view(Request $request)
{
    $currentDateTime = now();
    $userId = $request->input('user_id');

    // 获取所有用户
    $users = User::all();

    // 构建查询
    $query = Appointment::with('redeemedVouchers.voucher', 'barber');
    if ($userId) {
        $query->where('user_id', $userId);
    }

    // Future and ongoing appointments
    $appointments = $query->where(function ($query) use ($currentDateTime) {
        $query->where('date', '>', $currentDateTime->format('Y-m-d'))
            ->orWhere(function ($query) use ($currentDateTime) {
                $query->where('date', $currentDateTime->format('Y-m-d'))
                    ->where('time', '>=', $currentDateTime->format('H:i:s'));
            });
    })
    ->orderBy('date', 'asc')
    ->orderBy('time', 'asc')
    ->get();

    // Past appointments
    $pastAppointments = $query->where(function ($query) use ($currentDateTime) {
        $query->where('date', '<', $currentDateTime->format('Y-m-d'))
            ->orWhere(function ($query) use ($currentDateTime) {
                $query->where('date', $currentDateTime->format('Y-m-d'))
                    ->where('time', '<', $currentDateTime->format('H:i:s'));
            });
    })
    ->get();

    return view('showAppointment', [
        'appointments' => $appointments,
        'pastAppointments' => $pastAppointments,
        'users' => $users,
        'selectedUser' => $userId,
    ]);
}

    public function viewU()
    {
        $currentDateTime = now();
        $user = auth()->user();

        // Future and ongoing appointments
        $appointments = $user->appointments()
        ->with('redeemedVouchers.voucher', 'barber')
        ->where(function ($query) use ($currentDateTime) {
            $query->where('date', '>', $currentDateTime->format('Y-m-d'))
                ->orWhere(function ($query) use ($currentDateTime) {
                    $query->where('date', $currentDateTime->format('Y-m-d'))
                        ->where('time', '>=', $currentDateTime->format('H:i:s'));
                });
            })
            ->orderBy('date', 'asc')
            ->get()
            ->groupBy('date');

        // Past appointments
        $pastAppointments = $user->appointments()
        ->with('redeemedVouchers.voucher', 'barber')
        ->where(function ($query) use ($currentDateTime) {
            $query->where('date', '<', $currentDateTime->format('Y-m-d'))
                ->orWhere(function ($query) use ($currentDateTime) {
                    $query->where('date', $currentDateTime->format('Y-m-d'))
                        ->where('time', '<', $currentDateTime->format('H:i:s'));
                });
            })
            ->get();

        return view('UshowAppointment', [
            'appointments' => $appointments,
            'pastAppointments' => $pastAppointments,
            'currentDateTime' => $currentDateTime,
        ]);
    }

    public function edit($id)
{
    $appointment = Appointment::find($id);
    if (!$appointment) {
        return redirect()->route('showAppointment')->with('error', 'Appointment not found');
    }

    $services = Service::all();
    $barbers = Barber::all();
    $vouchers = Voucher::where('is_active', true)->get(); // Fetch active vouchers
    $selectedServiceIds = json_decode($appointment->service, true) ? array_column(json_decode($appointment->service, true), 'id') : [];
    $redeemedVouchers = RedeemedVoucher::where('user_id', auth()->id())
                                       ->where('is_used', false)
                                       ->get();

    return view('editAppointment', [
        'appointment' => $appointment,
        'services' => $services,
        'barbers' => $barbers,
        'vouchers' => $vouchers,
        'selectedServiceIds' => $selectedServiceIds,    
        'redeemedVouchers' => $redeemedVouchers // Make sure this line is present
    ]);
}

    public function delete($id)
    {
        $appointment = Appointment::find($id);
        if ($appointment) {
            $appointment->delete();
            return redirect()->route('showAppointment')->with('success', 'Appointment deleted successfully!');
        }

        return redirect()->route('showAppointment')->with('error', 'Appointment not found');
    }

    public function deleteU($id)
    {
        $appointment = Appointment::find($id);
        if ($appointment) {
            $appointment->delete();
            return redirect()->route('UshowAppointment')->with('success', 'Appointment deleted successfully!');
        }

        return redirect()->route('UshowAppointment')->with('error', 'Appointment not found');
    }

    public function updateU(Request $request)
    {
        $appointment = Appointment::find($request->id);
        if (!$appointment) {
            return redirect()->route('UshowAppointment')->with('error', 'Appointment not found');
        }

        $validatedData = $request->validate([
            'date' => 'required|date',
            'time' => 'required',
            'barberID' => 'required|exists:barbers,id',
            'service' => 'required|array',
            'service.*' => 'exists:services,id',
            'voucher' => 'nullable|exists:redeemed_vouchers,id',
            'phoneNumber' => 'required|string',
            'outlet' => 'required|string',
        ]);

        $selectedServices = Service::whereIn('id', $request->service)->get();
        $servicesWithDetails = $selectedServices->map(function($service) {
            return [
                'id' => $service->id,
                'name' => $service->name,
                'cost' => $service->cost,
                'duration' => $service->duration
            ];
        })->toArray();

        $totalPrice = array_sum(array_column($servicesWithDetails, 'cost'));
        $totalTime = array_sum(array_column($servicesWithDetails, 'duration'));

        $barberId = $request->input('barberID');
        $barber = Barber::find($barberId);
        $barberCost = $barber ? $barber->cost : 0;
        $totalPrice += $barberCost;

        $voucherId = $request->input('voucher');
    $redeemedVouchers = null;
    if ($voucherId) {
        $redeemedVouchers = RedeemedVoucher::where('id', $voucherId)
                                          ->where('user_id', auth()->id())
                                          ->where('is_used', false)
                                          ->first();

        if ($redeemedVouchers) {
            // Apply the voucher discount
            $totalPrice -= $redeemedVouchers->voucher->discount;
            $totalPrice = max($totalPrice, 0);
        } else {
            return redirect()->back()->withErrors('Invalid or already used voucher');
        }
    }
    $startTime = Carbon::parse($request->time);
    $endTime = $startTime->copy()->addMinutes($totalTime);

    $appointment->date = $request->date;
    $appointment->time = $request->time;
    $appointment->endTime = $endTime->format('H:i:s');
    $appointment->phoneNumber = $request->phoneNumber;
    $appointment->outlet = $request->outlet;
    $appointment->service = json_encode($servicesWithDetails);
    $appointment->totalPrice = $totalPrice;
    $appointment->totalTime = $totalTime;
    $appointment->barber_id = $barberId;
    $appointment->voucher_id = $redeemedVouchers ? $voucherId : null;

    $appointment->save();

    if ($redeemedVouchers) {
        $redeemedVouchers->is_used = true;
        $redeemedVouchers->appointment_id = $appointment->id;
        $redeemedVouchers->save();
    }

        return redirect()->route('UshowAppointment')->with('success', 'Appointment updated successfully');
    }   

    public function update(Request $request)
{
    // Find the appointment by ID
    $appointment = Appointment::find($request->id);
    if (!$appointment) {
        return redirect()->route('showAppointment')->with('error', 'Appointment not found');
    }

    // Validate the input
    $validatedData = $request->validate([
        'date' => 'required|date',
        'time' => 'required',
        'barberID' => 'required|exists:barbers,id',
        'service' => 'required|array',
        'service.*' => 'exists:services,id',
        'voucher' => 'nullable|exists:redeemed_vouchers,id',
        'phoneNumber' => 'required|string',
        'outlet' => 'required|string',
    ]);

    // Get selected services and calculate total price and time
    $selectedServices = Service::whereIn('id', $request->service)->get();
    $servicesWithDetails = $selectedServices->map(function($service) {
        return [
            'id' => $service->id,
            'name' => $service->name,
            'cost' => $service->cost,
            'duration' => $service->duration
        ];
    })->toArray();

    $totalPrice = array_sum(array_column($servicesWithDetails, 'cost'));
    $totalTime = array_sum(array_column($servicesWithDetails, 'duration'));

    // Get barber cost and add to total price
    $barberId = $request->input('barberID');
    $barber = Barber::find($barberId);
    $barberCost = $barber ? $barber->cost : 0;
    $totalPrice += $barberCost;

    // Handle the voucher if one was provided
    $voucherId = $request->input('voucher');
    $redeemedVouchers = null;
    if ($voucherId) {
        $redeemedVouchers = RedeemedVoucher::where('id', $voucherId)
                                          ->where('user_id', auth()->id())
                                          ->where('is_used', false)
                                          ->first();

        if ($redeemedVouchers) {
            // Apply the voucher discount
            $totalPrice -= $redeemedVouchers->voucher->discount;
            $totalPrice = max($totalPrice, 0);
        } else {
            return redirect()->back()->withErrors('Invalid or already used voucher');
        }
    }

    // Calculate end time
    $startTime = Carbon::parse($request->time);
    $endTime = $startTime->copy()->addMinutes($totalTime);

    // Update the existing appointment
    $appointment->date = $request->date;
    $appointment->time = $request->time;
    $appointment->endTime = $endTime->format('H:i:s');
    $appointment->phoneNumber = $request->phoneNumber;
    $appointment->outlet = $request->outlet;
    $appointment->service = json_encode($servicesWithDetails);
    $appointment->totalPrice = $totalPrice;
    $appointment->totalTime = $totalTime;
    $appointment->barber_id = $barberId;
    $appointment->voucher_id = $redeemedVouchers ? $voucherId : null;

    $appointment->save();

    // If a voucher was used, mark it as used and associate it with the appointment
    if ($redeemedVouchers) {
        $redeemedVouchers->is_used = true;
        $redeemedVouchers->appointment_id = $appointment->id;
        $redeemedVouchers->save();
    }

    return redirect()->route('showAppointment')->with('success', 'Appointment updated successfully');
}

    public function showAddForm() {
        $services = Service::all();
        $barbers = Barber::all();
        $user = auth()->user();
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please log in to view appointment options.');
        }
    
        // Fetch redeemed vouchers for the current user that are not yet used
        $redeemedVouchers = RedeemedVoucher::where('user_id', $user->id)
                                           ->where('is_used', false)
                                           ->get();
    
        return view('UaddAppointment', [
            'services' => $services,
            'barbers' => $barbers,
            'redeemedVouchers' => $redeemedVouchers // Pass redeemed vouchers to the view
        ]);   
    }
    public function Uhistory()
    {
        $now = now();

        $appointments = Appointment::where(function($query) use ($now) {
            $query->whereDate('date', '<', $now->toDateString())
                ->orWhere(function($query) use ($now) {
                    $query->whereDate('date', $now->toDateString())
                          ->whereTime('time', '<', $now->toTimeString());
                });
        })
        ->where('status', '!=', 'history')
        ->get();

        return view('UappointmentHistory', [
            'appointments' => $appointments
        ]);
    }

    public function history()
    {
        $now = now();

        $appointments = Appointment::where(function($query) use ($now) {
            $query->whereDate('date', '<', $now->toDateString())
                ->orWhere(function($query) use ($now) {
                    $query->whereDate('date', $now->toDateString())
                          ->whereTime('time', '<', $now->toTimeString());
                });
        })
        ->where('status', '!=', 'history')
        ->get();

        return view('appointmentHistory', [
            'appointments' => $appointments
        ]);
    }

    public function checkBarberAvailability(Request $request)
    {
        $date = $request->input('date');
        $time = $request->input('time');
        $services = $request->input('services');

        $startDateTime = Carbon::createFromFormat('Y-m-d H:i', $date . ' ' . $time);
        $totalDuration = Service::whereIn('id', $services)->sum('duration');
        $endDateTime = clone $startDateTime;
        $endDateTime->addMinutes($totalDuration);

        $unavailableBarbers = Appointment::where('date', $date)
        ->where(function ($query) use ($startDateTime, $endDateTime) {
            $query->where(function ($query) use ($startDateTime, $endDateTime) {
                $query->where(function ($query) use ($startDateTime, $endDateTime) {
                    $query->whereBetween('time', [$startDateTime->format('H:i:s'), $endDateTime->format('H:i:s')])
                          ->orWhereRaw('? BETWEEN time AND ADDTIME(time, SEC_TO_TIME(totalTime * 60))', [$startDateTime->format('H:i:s')])
                          ->orWhereRaw('? BETWEEN time AND ADDTIME(time, SEC_TO_TIME(totalTime * 60))', [$endDateTime->format('H:i:s')]);
                });
            });
        })
        ->pluck('barber_id');

        return response()->json(['unavailableBarbers' => $unavailableBarbers]);
    }

    public function getBarberAvailability(Request $request)
    {
        $date = $request->input('date');
        $appointments = Appointment::where('date', $date)->get();

        $bookedSlots = [];
        $barberAvailability = [];

        foreach ($appointments as $appointment) {
            $startTime = new DateTime($appointment->time);
            $endTime = clone $startTime;
            $endTime->modify("+{$appointment->totalTime} minutes");

            while ($startTime < $endTime) {
                $bookedSlots[] = $startTime->format('H:i');
                $startTime->modify('+30 minutes');
            }

            $barberAvailability[$appointment->barberID] = false; // Mark barber as unavailable
        }

        // Make all barbers available by default
        $barbers = Barber::all();
        foreach ($barbers as $barber) {
            if (!isset($barberAvailability[$barber->id])) {
                $barberAvailability[$barber->id] = true;
            }
        }

        return response()->json([
            'bookedSlots' => array_unique($bookedSlots),
            'barberAvailability' => $barberAvailability
        ]);
    }

    public function showCalendar()
    {
        $barbers = Barber::all();
        return view('UbarberCalendar', compact('barbers'));
    }

    public function viewCalendar()
    {
        $barbers = Barber::all();
        return view('UbarberCalendar', compact('barbers'));
    }


    public function getCalendarData($barberId)
    {
        $appointments = Appointment::where('barber_id', $barberId)->get();

        $events = $appointments->map(function($appointment) {
            $startTime = Carbon::parse($appointment->time);
            $endTime = $startTime->copy()->addMinutes($appointment->totalTime);

            \Log::info('Appointment: ' . $appointment->toJson());
            \Log::info('Start Time: ' . $startTime);
            \Log::info('End Time: ' . $endTime);

            return [
                'title' => 'Booked',
                'start' => $appointment->date . 'T' . $startTime->format('H:i:s'),
                'end' => $appointment->date . 'T' . $endTime->format('H:i:s'),
                'backgroundColor' => 'red',
                'borderColor' => 'red',
                'extendedProps' => [
                    'details' => [
                        'barber_name' => $appointment->barber->name,
                        'time' => $appointment->time,
                        'end_time' => $endTime->format('H:i:s'),
                    ],
                ],
        ];
    });

    $eventsArray = $events->toArray();
    \Log::info('Events: ' . json_encode($eventsArray));

    return response()->json($events);
}
}
