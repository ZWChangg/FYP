<?php

namespace App\Http\Controllers;

use App\Models\Voucher;
use App\Models\RedeemedVoucher;
use Illuminate\Http\Request;

class VoucherController extends Controller
{
    // 显示所有Voucher
    public function view()
    {
        $vouchers = Voucher::with('redeemedVouchers.user')->get();
        return view('showVoucher', compact('vouchers'));
    }

    public function showAddForm()
    {
        $vouchers = Voucher::where('is_active', true)->get(); // Get all active vouchers
        $redeemedVouchers = RedeemedVoucher::all(); // Get all redeemed vouchers

        return view('addVoucher', compact('vouchers', 'redeemedVouchers'));
    }

    // 处理创建新Voucher的请求
    public function add(Request $request)
{
    $request->validate([
        'name' => 'required|string|max:255',
        'discount' => 'required|numeric',
        'points_required' => 'required|integer|min:1', // Validate this field
        'is_active' => 'required|boolean',
    ]);

    Voucher::create([
        'name' => $request->input('name'),
        'discount' => $request->input('discount'),
        'points_required' => $request->input('points_required'),
        'is_active' => $request->input('is_active'),
    ]);

    return redirect()->route('showVoucher')->with('success', 'Voucher added successfully!');
}


    // 显示编辑Voucher的表单
    public function edit($id)
    {
        $voucher = Voucher::findOrFail($id);
        return view('editVoucher', compact('voucher'));
    }

    // 处理编辑Voucher的请求
    public function update(Request $request, $id)
{
    $request->validate([
        'name' => 'required|string|max:255',
        'discount' => 'required|numeric',
        'points_required' => 'required|integer|min:1',
        'is_active' => 'required|boolean',
    ]);

    $voucher = Voucher::findOrFail($id);
    $voucher->update([
        'name' => $request->input('name'),
        'discount' => $request->input('discount'),
        'points_required' => $request->input('points_required'),
        'is_active' => $request->input('is_active'),
    ]);

    return redirect()->route('showVoucher')->with('success', 'Voucher updated successfully.');
}


    // 删除Voucher
    public function delete($id)
    {
    $voucher = Voucher::find($id);
    if ($voucher) {
        $voucher->delete();

        return redirect()->route('showVoucher')->with('success', 'Voucher deleted successfully!');
    }

    return redirect()->route('showVoucher')->with('error', 'Voucher not found');
    }

    // 显示Voucher兑换记录
    public function showAllRedeemedRecord()
{
    $redeemedVouchers = RedeemedVoucher::with('user', 'voucher', 'appointment')
        ->orderBy('created_at', 'desc')
        ->get();

    return view('redeemedRecord', compact('redeemedVouchers'));
}

public function editRD($id)
{
    $redeemedVoucher = RedeemedVoucher::with('user', 'voucher', 'appointment')->find($id);
    if (!$redeemedVoucher) {
        return redirect()->route('redeemedRecord')->with('error', 'Redeemed Voucher not found');
    }

    return view('editRedeemedRecord', compact('redeemedVoucher'));
}

public function updateRD(Request $request, $id)
{
    $redeemedVoucher = RedeemedVoucher::find($id);
    if (!$redeemedVoucher) {
        return redirect()->route('redeemedRecord')->with('error', 'Redeemed Voucher not found');
    }

    // Validate the input
    $validatedData = $request->validate([
        'is_used' => 'required|boolean',
        'appointment_id' => 'nullable|exists:appointments,id',
    ]);

    // Update the redeemed voucher
    $redeemedVoucher->is_used = $validatedData['is_used'];
    $redeemedVoucher->appointment_id = $validatedData['appointment_id'];
    $redeemedVoucher->save();

    return redirect()->route('redeemedRecord')->with('success', 'Redeemed Voucher updated successfully');
}

}
