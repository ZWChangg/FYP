<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Service;
use Session;

class ServiceController extends Controller
{
    public function add(Request $request) {
        $imageName = "empty.jpg";
        if ($request->hasFile('image')) {
            $imageFile = $request->file('image');
            $imageName = time() . '_' . $imageFile->getClientOriginalName();
            $imageFile->move(public_path('images'), $imageName);
        }
    
        $service = Service::create([
            'name' => $request->name,
            'duration' => $request->duration,
            'cost' => $request->cost,
            'image' => $imageName,
        ]);
        
        return redirect()->route('showService')->with('success', 'Service added successfully!');
    }
        

    public function view() {
        $services = Service::all();
        return view('showService')->with('services', $services);
    }

    public function Uview() {
        $services = Service::all();
        return view('UshowService')->with('services', $services);
    }

    public function edit($id) {
        $service = Service::find($id);
        return view('editService')->with('services', [$service]);
    }

    public function delete($id) {
        $service = Service::find($id);
        $service->delete(); 
        Session::flash('success', "Service deleted");
        return redirect()->route('showService');
    }

    public function update(Request $request) {
        $service = Service::find($request->id);
        if ($service) {
            $service->name = $request->name;
            $service->duration = $request->duration;
            $service->cost = $request->cost;
    
            // 处理图像上传
            if ($request->hasFile('image')) {
                $imageFile = $request->file('image');
                $imageName = time() . '_' . $imageFile->getClientOriginalName();
                $imageFile->move(public_path('images'), $imageName);
                $service->image = $imageName;
            }
    
            $service->save();
            return redirect()->route('showService')->with('success', 'Service updated successfully!');
        } else {
            return redirect()->route('showService')->withErrors('Service not found.');
        }
    }
    

    public function aboutUs(){
        return view('UaboutUs');
    }

}

