<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Point;
use App\Models\User;
use App\Models\Service;
use App\Models\Barber;
use App\Models\Voucher;
use App\Models\RedeemedVoucher;
use Illuminate\Http\Request;

class PointController extends Controller
{
    // 显示所有用户的积分记录
    public function showAddForm()
    {
        $user = User::first();
        $users = User::all();
        $transactions = Point::with('user')->get();
        return view('addPoint', compact('users', 'transactions', 'user'));
    }

    // 显示特定用户的积分记录
    public function view(Request $request)
    {
        $users = User::all();
        $selectedUser = null;
        $transactions = collect(); // Empty collection by default
    
        if ($request->has('user_id')) {
            $selectedUser = User::findOrFail($request->input('user_id'));
            $transactions = Point::where('user_id', $selectedUser->id)->get();
        }
    
        return view('showPoint', compact('users', 'selectedUser', 'transactions'));
    }    

    // 增加用户积分
public function add(Request $request)
{
    $request->validate([
        'user_id' => 'required|exists:users,id',
        'points' => 'required|integer|min:1',
        'description' => 'nullable|string',
    ]);

    $user = User::findOrFail($request->input('user_id'));
    $points = $request->input('points');
    $description = $request->input('description');

    $user->points += $points;
    $user->save();

    Point::create([
        'user_id' => $user->id,
        'transaction_type' => 'add',
        'points_changed' => $points,
        'description' => $description,
    ]);

    return redirect()->route('showPoint', $user->id)->with('success', 'Points added successfully!');
}

// 减少用户积分
public function sub(Request $request)
{
    $request->validate([
        'user_id' => 'required|exists:users,id',
        'points' => 'required|integer|min:1',
        'description' => 'nullable|string',
    ]);

    $user = User::findOrFail($request->input('user_id'));
    $points = $request->input('points');
    $description = $request->input('description');

    if ($user->points >= $points) {
        $user->points -= $points;
        $user->save();

        Point::create([
            'user_id' => $user->id,
            'transaction_type' => 'redeem',
            'points_changed' => -$points,
            'description' => $description,
        ]);

        return redirect()->route('showPoint', $user->id)->with('success', 'Points subtracted successfully!');
    } else {
        return redirect()->back()->withErrors(['message' => 'Not enough points to subtract.']);
    }
}

    public function redeemPoints(Request $request)
{
    $user = auth()->user();
    $voucher = Voucher::findOrFail($request->input('voucher_id'));

    if ($user->points >= $voucher->points_required) {
        // Deduct points from the user
        $user->points -= $voucher->points_required;
        $user->save();

        // Create a RedeemedVoucher record
        RedeemedVoucher::create([
            'user_id' => $user->id,
            'voucher_id' => $voucher->id,
            'discount' => $voucher->discount,
            'is_used' => false,
        ]);

        // Create a Point transaction record for the redemption
        Point::create([
            'user_id' => $user->id,
            'transaction_type' => 'redeem',
            'discount' => $voucher->discount,
            'points_changed' => -$voucher->points_required,
            'description' => $voucher->name,
        ]);

        return redirect()->back()->with('success', 'Voucher redeemed successfully!');
    }

    return redirect()->back()->with('error', 'Not enough points.');
}

public function showRedeemPoints()
{
    $user = auth()->user(); // 获取当前登录的用户
    $userPoints = $user->points;

    // 获取当前用户可用的所有代金券
    $vouchers = Voucher::where('is_active', true)->get();

    // 获取当前用户已兑换且未使用的代金券
    $redeemedVouchers = $user->redeemedVouchers()->where('is_used', false)->get();

    // 获取当前用户的积分交易记录，按创建时间倒序排序
    $transactions = Point::where('user_id', $user->id)->orderBy('created_at', 'desc')->get();

    return view('UredeemPoint', compact('vouchers', 'redeemedVouchers', 'userPoints', 'transactions'));
}

}
    