<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\AuthenticatesUsers;


class AdminController extends Controller
{
    /**
     * 显示管理员登录表单页面
     */
    public function showLoginForm()
    {
        return view('auth.adminlogin');
    }

    public function login(Request $request){
        $request->validate([
            'admin_id' => 'required',
        ]);

        $adminId = 'admin123';

        if ($request->admin_id === $adminId) {
            return redirect()->route('barberInfo');
        } else {
            return redirect()->route('admin.login.form')->withErrors(['admin_id' => 'Invalid Admin ID']);
        }
    }
}
